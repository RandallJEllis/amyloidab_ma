# Anti-amyloid antibody reanalysis package

This package reproduces the supplied Cochrane CD016297 analyses and applies the criteria requested in Snyder et al. (2026): biological separation by plaque clearance, biomarker-confirmed enrollment, treatment-generation sensitivities, raw mean differences, and continuous amyloid-clearance moderation.

## Main deliverables

- `alzheimers_antibody_reanalysis_report.pdf`: methods, results, figures, interpretation, and limitations.
- `alzheimers_antibody_reanalysis.xlsx`: auditable workbook containing the protocol, key findings, all outcome/scenario estimates, raw mean differences, meta-regressions, amyloid mapping, reproduction checks, cleaned rows, and sources.
- `code/reanalysis.R`: complete statistical analysis and figure-generation script.
- `data/*.csv`: cleaned study-analysis rows and all derived result tables.
- `figures/*.png`: report figures at publication-ready resolution.

## Run

From the project directory, with R 4.4+ and the `metafor`, `dplyr`, `readr`, `ggplot2`, and `jsonlite` packages installed:

```sh
Rscript code/reanalysis.R
```

The script expects the unzipped Cochrane data package at `work/source_extracts/cochrane_data/`. Paths can be adjusted at the top of the script.

## Primary response-conforming definition

The primary set requires all of the following:

1. Biomarker-confirmed enrollment.
2. An approved-generation antibody.
3. A documented placebo-adjusted amyloid PET reduction of at least 10 Centiloids.

This selects EMERGE, ENGAGE, CLARITY AD, and TRAILBLAZER-ALZ 2. The package also reports broader clearing-agent and currently-active-agent sensitivities so conclusions are not dependent on this definition alone.

## Important limitation

Amyloid-clearance models use aggregate trial-level estimates and cannot establish individual-level mediation or causality. This package is an evidence-synthesis reanalysis, not clinical guidance.
