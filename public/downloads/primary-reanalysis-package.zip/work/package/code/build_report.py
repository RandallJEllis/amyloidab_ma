from __future__ import annotations

import json
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, mm
from reportlab.platypus import (
    BaseDocTemplate, Frame, PageTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, Image, KeepTogether
)

ROOT = Path(__file__).resolve().parent.parent
DATA = json.loads((ROOT / "work/results/analysis_results.json").read_text())
OUT = ROOT / "outputs/alzheimers_antibody_reanalysis_report.pdf"
FIG = ROOT / "work/results/figures"

NAVY = colors.HexColor("#17324D")
BLUE = colors.HexColor("#2E5D8A")
TEAL = colors.HexColor("#16837A")
PALE = colors.HexColor("#EAF2F8")
PALE_TEAL = colors.HexColor("#E7F5F2")
PALE_AMBER = colors.HexColor("#FFF5D9")
GRID = colors.HexColor("#D8E0E8")
INK = colors.HexColor("#1D2733")
MUTED = colors.HexColor("#5B6775")
RED = colors.HexColor("#B64545")

styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name="TitleWhite", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=23, leading=27, textColor=colors.white, spaceAfter=8))
styles.add(ParagraphStyle(name="SubWhite", parent=styles["Normal"], fontName="Helvetica", fontSize=10.5, leading=15, textColor=colors.HexColor("#DDE8F2")))
styles.add(ParagraphStyle(name="H1x", parent=styles["Heading1"], fontName="Helvetica-Bold", fontSize=17, leading=21, textColor=NAVY, spaceBefore=4, spaceAfter=9))
styles.add(ParagraphStyle(name="H2x", parent=styles["Heading2"], fontName="Helvetica-Bold", fontSize=12.5, leading=16, textColor=BLUE, spaceBefore=8, spaceAfter=5))
styles.add(ParagraphStyle(name="Bodyx", parent=styles["BodyText"], fontName="Helvetica", fontSize=9.3, leading=13.1, textColor=INK, spaceAfter=7))
styles.add(ParagraphStyle(name="Smallx", parent=styles["BodyText"], fontName="Helvetica", fontSize=7.5, leading=10, textColor=INK))
styles.add(ParagraphStyle(name="Tinyx", parent=styles["BodyText"], fontName="Helvetica", fontSize=6.3, leading=8, textColor=INK))
styles.add(ParagraphStyle(name="Callout", parent=styles["BodyText"], fontName="Helvetica-Bold", fontSize=9.2, leading=13, textColor=NAVY, backColor=PALE_AMBER, borderPadding=8, spaceAfter=9))
styles.add(ParagraphStyle(name="Captionx", parent=styles["BodyText"], fontName="Helvetica-Oblique", fontSize=7.5, leading=10, textColor=MUTED, alignment=TA_CENTER, spaceBefore=3, spaceAfter=8))
styles.add(ParagraphStyle(name="TableHead", parent=styles["BodyText"], fontName="Helvetica-Bold", fontSize=7, leading=8, textColor=colors.white, alignment=TA_LEFT))
styles.add(ParagraphStyle(name="TableCell", parent=styles["BodyText"], fontName="Helvetica", fontSize=6.8, leading=8.2, textColor=INK))


def header_footer(canvas, doc):
    canvas.saveState()
    width, height = A4
    canvas.setStrokeColor(GRID)
    canvas.setLineWidth(0.4)
    canvas.line(18 * mm, 14 * mm, width - 18 * mm, 14 * mm)
    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(MUTED)
    canvas.drawRightString(width - 18 * mm, 10 * mm, f"Page {doc.page}")
    canvas.restoreState()


doc = BaseDocTemplate(
    str(OUT), pagesize=A4, rightMargin=17 * mm, leftMargin=17 * mm,
    topMargin=21 * mm, bottomMargin=16 * mm, title="Anti-amyloid antibody reanalysis"
)
frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="normal")
doc.addPageTemplates(PageTemplate(id="main", frames=frame, onPage=header_footer))


def p(txt, style="Bodyx"):
    return Paragraph(txt, styles[style])


def fmt(x, digits=3):
    if x is None:
        return "NA"
    if isinstance(x, (int, float)):
        if abs(x) < 0.0001 and x != 0:
            return f"{x:.2e}"
        return f"{x:.{digits}f}"
    return str(x)


def effect_row(analysis_id, scenario):
    for r in DATA["outcome_sensitivities"]:
        if r["analysis_id"] == analysis_id and r["scenario"] == scenario:
            return r
    return None


def raw_row(analysis_id, scenario):
    for r in DATA["raw_mean_differences"]:
        if r["analysis_id"] == analysis_id and r["scenario"] == scenario:
            return r
    return None


COCH = "Cochrane class pool"
PRIMARY = "Response primary: clearing approved-generation trials"
CLEAR = "Demonstrated clearance: >=10 CL"
ACTIVE = "Currently active agents: lecanemab + donanemab"


def outcome_table(ids, scenarios=(COCH, PRIMARY), raw=False):
    rows = [[p("Outcome", "TableHead"), p("Scenario", "TableHead"), p("k", "TableHead"),
             p("Measure", "TableHead"), p("Estimate (95% CI)", "TableHead"), p("P", "TableHead"), p("I2", "TableHead")]]
    for aid in ids:
        for scenario in scenarios:
            r = raw_row(aid, scenario) if raw else effect_row(aid, scenario)
            if not r:
                continue
            label = r["outcome"]
            scen = {COCH: "Cochrane class pool", PRIMARY: "Response primary", CLEAR: ">=10 CL clearers", ACTIVE: "Lecanemab + donanemab"}[scenario]
            rows.append([
                p(label, "TableCell"), p(scen, "TableCell"), p(str(r["k"]), "TableCell"),
                p(r["measure"], "TableCell"), p(f"{fmt(r['estimate'])} ({fmt(r['ci_low'])}, {fmt(r['ci_high'])})", "TableCell"),
                p(fmt(r["p_value"], 4), "TableCell"), p("NA" if r.get("i2") is None else fmt(r["i2"], 1) + "%", "TableCell")
            ])
    table = Table(rows, colWidths=[53*mm, 34*mm, 8*mm, 13*mm, 38*mm, 16*mm, 14*mm], repeatRows=1, hAlign="LEFT")
    table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), BLUE), ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("VALIGN", (0,0), (-1,-1), "TOP"), ("GRID", (0,0), (-1,-1), 0.25, GRID),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, PALE]),
        ("LEFTPADDING", (0,0), (-1,-1), 4), ("RIGHTPADDING", (0,0), (-1,-1), 4),
        ("TOPPADDING", (0,0), (-1,-1), 3), ("BOTTOMPADDING", (0,0), (-1,-1), 3),
    ]))
    return table


story = []

# Cover
story.append(Spacer(1, 24*mm))
cover = Table([[p("Anti-amyloid antibody reanalysis", "TitleWhite")],
               [p("A response-conforming reanalysis of Cochrane CD016297", "SubWhite")],
               [p("Trial exclusions, raw mean differences, and continuous amyloid-clearance sensitivity analyses", "SubWhite")]],
              colWidths=[doc.width])
cover.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,-1), NAVY), ("BOX", (0,0), (-1,-1), 0, NAVY),
                           ("LEFTPADDING", (0,0), (-1,-1), 16), ("RIGHTPADDING", (0,0), (-1,-1), 16),
                           ("TOPPADDING", (0,0), (-1,0), 18), ("BOTTOMPADDING", (0,-1), (-1,-1), 18)]))
story.append(cover)
story.append(Spacer(1, 12*mm))
story.append(p("Prepared from the supplied Cochrane review PDF, response EPUB, analysis HTML, and Cochrane data package. Trial-level amyloid PET changes were added from primary trial reports and a published cross-trial extraction with transparent mapping.", "Bodyx"))
story.append(Spacer(1, 5*mm))
story.append(p("Analysis date: 14 August 2026", "Bodyx"))
story.append(p("Scope: aggregate randomized-trial evidence only. This document does not make individual treatment recommendations.", "Callout"))
story.append(PageBreak())

# Executive summary
story.append(p("Executive summary", "H1x"))
adas = effect_row("1.1", PRIMARY); adas_all = effect_row("1.1", COCH); adas_md = raw_row("1.1", PRIMARY); adas_md_all = raw_row("1.1", COCH)
cdr = effect_row("2.1", PRIMARY); cdr_all = effect_row("2.1", COCH); cdr_md = raw_row("2.1", PRIMARY); cdr_md_all = raw_row("2.1", COCH)
ariae = effect_row("4.2", PRIMARY); ariah = effect_row("4.7", PRIMARY); sae = effect_row("5.1", PRIMARY); mort = effect_row("6.1", PRIMARY); disc = effect_row("9.1", PRIMARY)
story.append(p(
    "The central criticism in the researcher response is analytically consequential: combining antibodies with materially different plaque-clearing activity dilutes the estimated clinical effect. After restricting to biomarker-confirmed, approved-generation trials with documented plaque reduction of at least 10 Centiloids (EMERGE, ENGAGE, CLARITY AD, and TRAILBLAZER-ALZ 2), the pooled effect becomes larger for cognition and function than in Cochrane's class-level analysis. The tradeoff is equally clear: ARIA and discontinuation risks are more concentrated in the same trials.", "Bodyx"))
story.append(p(
    f"At about 18 months, ADAS-Cog changed from SMD {fmt(adas_all['estimate'])} to {fmt(adas['estimate'])}; in raw scale units, the mean difference changed from {fmt(adas_md_all['estimate'],2)} to {fmt(adas_md['estimate'],2)} points favoring antibody. CDR-SB changed from SMD {fmt(cdr_all['estimate'])} to {fmt(cdr['estimate'])}; the raw difference was {fmt(cdr_md['estimate'],2)} points (95% CI {fmt(cdr_md['ci_low'],2)} to {fmt(cdr_md['ci_high'],2)}).", "Bodyx"))
story.append(p(
    f"For the primary response-conforming set, any ARIA-E had RR {fmt(ariae['estimate'],2)} (95% CI {fmt(ariae['ci_low'],2)} to {fmt(ariae['ci_high'],2)}), any ARIA-H RR {fmt(ariah['estimate'],2)} ({fmt(ariah['ci_low'],2)} to {fmt(ariah['ci_high'],2)}), and study discontinuation RR {fmt(disc['estimate'],2)} ({fmt(disc['ci_low'],2)} to {fmt(disc['ci_high'],2)}). Serious adverse events and mortality remained too imprecise to establish a difference: RR {fmt(sae['estimate'],2)} and {fmt(mort['estimate'],2)}, respectively.", "Bodyx"))
story.append(p(
    "Continuous meta-regression pointed in the same direction - more plaque reduction was associated with greater average benefit - but did not cross the conventional 0.05 threshold for either ADAS-Cog or CDR-SB. With only six to eight matched trials and aggregate data, this is suggestive rather than decisive.", "Bodyx"))
story.append(p(
    "Bottom line: the response is right that class-level pooling masks meaningful biological and treatment-specific heterogeneity. The restricted analyses support statistically detectable slowing on several outcomes. They do not, by themselves, resolve clinical meaningfulness or benefit-risk judgments: the raw mean effects remain below the MCIDs cited by Cochrane, while ARIA and treatment discontinuation clearly increase.", "Callout"))

story.append(p("Key 18-month estimates", "H2x"))
story.append(outcome_table(["1.1", "2.1", "3.5", "3.6", "4.2", "4.7", "5.1", "6.1", "9.1"]))
story.append(PageBreak())

# Specification and data
story.append(p("1. Analysis specification derived from the response", "H1x"))
story.append(p("The response did not prescribe a single numerical meta-analysis. It identified defects and desired corrections. Those were translated into the following operational rules before examining restricted results:", "Bodyx"))
rules = [
    ("Biological separation", "Do not treat every beta-amyloid monoclonal antibody as exchangeable. Distinguish trials by demonstrated plaque reduction and contemporary clinical use."),
    ("Biomarker-defined disease", "Separate trials requiring abnormal amyloid PET or CSF at enrollment from older clinically defined populations."),
    ("Interpretable scales", "Report raw mean differences when the same clinical scale is used, alongside SMDs for comparability."),
    ("Treatment-specific evidence", "Show approved-generation and currently active agents separately rather than allowing failed development programs to determine their estimate."),
    ("Bounded inference", "Report statistical effects and uncertainty without converting a systematic review into a treatment guideline or causal proof of mechanism.")
]
rt = Table([[p(a, "TableCell"), p(b, "TableCell")] for a,b in rules], colWidths=[42*mm, 125*mm])
rt.setStyle(TableStyle([("BACKGROUND",(0,0),(0,-1),PALE_TEAL),("TEXTCOLOR",(0,0),(0,-1),NAVY),("FONTNAME",(0,0),(0,-1),"Helvetica-Bold"),
                            ("GRID",(0,0),(-1,-1),0.3,GRID),("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6),("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5)]))
story.append(rt)
story.append(p("Primary response-conforming set", "H2x"))
story.append(p("The primary set required all three conditions: biomarker-confirmed enrollment; an approved-generation antibody; and a matched placebo-adjusted amyloid PET reduction of at least 10 Centiloids. This selected EMERGE, ENGAGE, CLARITY AD, and TRAILBLAZER-ALZ 2. ENVISION was excluded because a matched trial-level Centiloid estimate was not available. Separate sensitivity analyses included every trial with documented >=10-Centiloid clearance and the two agents in active clinical use in 2026 (lecanemab and donanemab).", "Bodyx"))
story.append(p("Why 10 Centiloids?", "H2x"))
story.append(p("The response itself did not define a numerical threshold. A published cross-trial analysis used >10 Centiloids as the radiologically meaningful plaque-reduction threshold, reasoning that changes below this level are near the transition from no pathology to subtle pathology. Because threshold choice is contestable, the continuous analysis was prespecified as a co-primary sensitivity rather than relying on the dichotomy alone.", "Bodyx"))

story.append(p("2. Data integrity and reproduction", "H1x"))
story.append(p("The Cochrane archive contains 358 study-analysis rows, 84 overall analysis settings/results, 199 subgroup estimates, study metadata, and risk-of-bias fields. The reanalysis used the original analysis groups 1 through 9 and did not alter the supplied source files.", "Bodyx"))
story.append(p("Reconstructed class-pool point estimates matched the supplied Cochrane results to a maximum absolute difference below 0.00005. This validates outcome selection, study mapping, and effect-scale handling. Some reconstructed confidence intervals differ for a subset of small-k and dichotomous analyses because RevMan and metafor implement small-sample/Hartung-Knapp adjustments differently; point estimates and substantive conclusions were not affected.", "Bodyx"))
story.append(p("The Cochrane package does not contain trial-level amyloid PET change. Those values were mapped from Imbimbo et al. (2024), supplemented for GRADUATE I and II by the primary NEJM report. Missing or ambiguous mappings were left missing, never imputed.", "Bodyx"))
story.append(PageBreak())

# Methods
story.append(p("3. Statistical methods", "H1x"))
story.append(p("For each supplied analysis, study estimates were synthesized with inverse-variance random-effects models. Between-study variance was estimated by restricted maximum likelihood (REML). Hartung-Knapp inference was used when at least three studies were available; normal/Wald inference was used for one or two studies. Dichotomous outcomes were modeled on the log risk-ratio scale and exponentiated for presentation.", "Bodyx"))
story.append(p("Raw mean differences were calculated as active-arm minus placebo-arm mean change, with sampling variance SD(active)^2/n(active) + SD(placebo)^2/n(placebo), when both arm means, SDs, and analyzed sample sizes were present. Adjusted contrast-level MDs already supplied by Cochrane were analyzed directly.", "Bodyx"))
story.append(p("The continuous sensitivity regressed each study's clinical effect on placebo-adjusted plaque reduction, expressed per additional 10 Centiloids of clearance. These are trial-level ecological models; no individual participant data were available, and no claim of mediation is warranted.", "Bodyx"))
story.append(p("Effect directions", "H2x"))
story.append(p("Negative ADAS-Cog and CDR-SB values favor antibody. Positive MMSE, ADCS-ADL, ADCS-ADL-MCI, ADCS-iADL, and DAD values favor antibody. For risk ratios, values above 1 indicate more events on antibody.", "Bodyx"))

# Efficacy
story.append(p("4. Efficacy findings", "H1x"))
story.append(p("Standardized effects", "H2x"))
story.append(outcome_table(["1.1", "1.4", "2.1", "3.2", "3.5", "3.6"], scenarios=(COCH, PRIMARY, CLEAR, ACTIVE)))
story.append(Spacer(1, 4*mm))
story.append(Image(str(FIG / "priority_endpoint_comparison.png"), width=165*mm, height=180*mm))
story.append(p("Figure 1. Primary and sensitivity estimates across key efficacy and safety endpoints. Axes vary by panel; risk ratios use a null of 1 and standardized mean differences use a null of 0.", "Captionx"))
story.append(PageBreak())

story.append(p("Raw clinical-scale effects", "H2x"))
story.append(outcome_table(["1.1", "1.4", "2.1", "3.1", "3.2"], scenarios=(COCH, PRIMARY, CLEAR, ACTIVE), raw=True))
story.append(Spacer(1, 4*mm))
story.append(Image(str(FIG / "raw_mean_difference_comparison.png"), width=165*mm, height=120*mm))
story.append(p("Figure 2. Unstandardized mean differences at approximately 18 months where arm-level means and SDs were available.", "Captionx"))
story.append(p("The response-conforming ADAS-Cog estimate was -1.31 points (95% CI -1.77 to -0.85), compared with -1.09 points for the full class pool. The response-conforming CDR-SB estimate was -0.39 points (95% CI -0.86 to 0.09). Cochrane cited MCIDs of roughly 2-3 ADAS-Cog points for MCI, 4 points for dementia, and 1 CDR-SB point for MCI. These pooled differences remain below those thresholds, although the response correctly notes that applying a single MCID across disease stages and time horizons is itself contestable.", "Bodyx"))
story.append(p("For ADCS-ADL-MCI, Cochrane's adjusted contrast-level MD analysis (analysis 3.8) yielded 1.88 points (95% CI 1.39 to 2.37) in the response-conforming set. ADCS-iADL was available only from TRAILBLAZER-ALZ 2 and favored donanemab by 1.75 points (95% CI 0.82 to 2.68).", "Bodyx"))
story.append(PageBreak())

# Continuous
story.append(p("5. Continuous amyloid-clearance sensitivity", "H1x"))
regrows = [[p("Outcome", "TableHead"),p("Scale", "TableHead"),p("k", "TableHead"),p("Slope per 10 CL (95% CI)", "TableHead"),p("P", "TableHead")]]
for r in DATA["meta_regressions"]:
    regrows.append([p(r["outcome"],"TableCell"),p(r["measure"],"TableCell"),p(str(r["k"]),"TableCell"),p(f"{fmt(r['slope_per_10cl'])} ({fmt(r['slope_ci_low'])}, {fmt(r['slope_ci_high'])})","TableCell"),p(fmt(r["slope_p"],4),"TableCell")])
regt=Table(regrows,colWidths=[64*mm,18*mm,10*mm,55*mm,18*mm],repeatRows=1)
regt.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),BLUE),("GRID",(0,0),(-1,-1),0.25,GRID),("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,PALE]),("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4),("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3)]))
story.append(regt)
story.append(p("For ADAS-Cog, the estimated SMD changed by -0.021 per additional 10 Centiloids cleared (95% CI -0.042 to 0.001; P=0.057). On the raw scale, this was -0.158 ADAS-Cog points per 10 Centiloids (95% CI -0.325 to 0.010; P=0.061). CDR-SB slopes also favored greater clearance but were less precise. These estimates align directionally with the response's biological argument, yet do not establish a statistically robust dose-response relation.", "Bodyx"))
story.append(Image(str(FIG / "clearance_meta_regression_1_1.png"), width=162*mm, height=105*mm))
story.append(p("Figure 3. Trial-level amyloid clearance and ADAS-Cog effect. Bubble area reflects precision.", "Captionx"))
story.append(Image(str(FIG / "clearance_meta_regression_2_1.png"), width=162*mm, height=105*mm))
story.append(p("Figure 4. Trial-level amyloid clearance and CDR-SB effect. Bubble area reflects precision.", "Captionx"))
story.append(PageBreak())

# Safety
story.append(p("6. Safety, tolerability, and the benefit-risk boundary", "H1x"))
story.append(outcome_table(["4.1","4.2","4.5","4.7","4.10","5.1","6.1","8.1","9.1"], scenarios=(COCH, PRIMARY, CLEAR, ACTIVE)))
story.append(p("The response-conforming restriction does not make harms disappear. Any ARIA-E was about eleven times more likely than placebo, any ARIA-H about twice as likely, and discontinuation about 28% more likely. Symptomatic ARIA-E produced very large relative risks because placebo events were extremely rare; the absolute event rate and treatment-specific risk are more clinically informative than the unstable relative estimate alone.", "Bodyx"))
story.append(p("Serious adverse events and mortality were imprecise and compatible with no difference. Their confidence intervals also permit clinically relevant harm or benefit. This reanalysis therefore cannot settle the benefit-risk judgment criticized in the response; doing so requires treatment-specific absolute risks, patient preferences, APOE genotype, MRI findings, monitoring capacity, and formal guideline methods.", "Callout"))

# Interpretation
story.append(PageBreak())
story.append(p("7. What changes relative to Cochrane - and what does not", "H1x"))
comparison = [
    ("Class homogeneity", "Changes materially", "Restricted estimates are larger, supporting the response's concern that lumping older/non-clearing agents dilutes efficacy."),
    ("Biomarker confirmation", "Changes modestly", "Cochrane already ran a biomarker-positive sensitivity. The present analysis combines biomarker confirmation with clearance and generation criteria."),
    ("Raw-scale interpretability", "Improves", "ADAS-Cog and CDR-SB effects can be expressed directly in points instead of requiring SMD back-conversion."),
    ("Statistical efficacy", "Stronger for several endpoints", "ADAS-Cog and ADCS-ADL-MCI favor the response-conforming set; CDR-SB is sensitive to model and subset."),
    ("Clinical meaningfulness", "Not resolved", "Pooled raw differences remain below Cochrane's cited MCIDs, but threshold selection and time horizon remain value-laden and methodologically contested."),
    ("Safety", "More concentrated", "ARIA and discontinuation risks increase or remain clearly elevated among effective plaque-clearing agents."),
    ("Mechanistic inference", "Still limited", "Trial-level association is suggestive but ecological, underpowered, and not proof that plaque removal mediates individual benefit."),
    ("Guideline conclusion", "Out of scope", "A systematic review alone cannot determine individual treatment choice or a universal benefit-risk balance.")
]
ct = Table([[p("Issue","TableHead"),p("Effect of reanalysis","TableHead"),p("Finding","TableHead")]] + [[p(a,"TableCell"),p(b,"TableCell"),p(c,"TableCell")] for a,b,c in comparison], colWidths=[39*mm,34*mm,94*mm], repeatRows=1)
ct.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),BLUE),("GRID",(0,0),(-1,-1),0.25,GRID),("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,PALE]),("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4),("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4)]))
story.append(ct)
story.append(PageBreak())

# Limitations and sources
story.append(p("8. Limitations", "H1x"))
limitations = [
    "This is aggregate-data reanalysis. Individual participant data were unavailable, so disease stage, APOE genotype, tau burden, dose exposure, and individual plaque clearance could not be modeled jointly.",
    "The response's phrase 'meaningfully clears amyloid' required an operational threshold. The >=10-Centiloid rule is literature-based but not uniquely mandated; continuous and active-agent sensitivities were included to reduce threshold dependence.",
    "Amyloid PET mapping is incomplete for several older trials and potentially sensitive to tracer conversion, dose selection, and time-point alignment. Missing values were excluded, not imputed.",
    "Some Cochrane rows use final/change scores, adjusted contrasts, or borrowed/imputed SDs. Raw MD analyses are limited to rows with extractable arm means, SDs, and sample sizes or supplied adjusted MDs.",
    "Small-k random-effects inference is unstable. Results may move under different Hartung-Knapp, modified Hartung-Knapp, Wald, or common-effect implementations.",
    "MCIDs vary by disease stage, anchor, follow-up duration, and whether they describe within-person change or between-group difference. They should not be treated as universal constants.",
    "The response authors report extensive relationships with advocacy organizations, manufacturers, and trial programs; Cochrane trials were industry funded. Those disclosures matter to interpretation but do not substitute for evaluating methods and data."
]
for item in limitations:
    story.append(p("- " + item, "Bodyx"))

story.append(p("9. Sources", "H1x"))
sources = [
    ("Cochrane CD016297", "Amyloid-beta-targeting monoclonal antibodies for people with mild cognitive impairment or mild dementia due to Alzheimer's disease. Cochrane Database of Systematic Reviews. 2026;4:CD016297. Supplied PDF, HTML, and data package."),
    ("Researcher response", "Snyder HM et al. Recent Cochrane review has serious flaws: A perspective of clinicians and researchers from around the world. Alzheimer's & Dementia. 2026;22(7). https://doi.org/10.1002/alz.71696"),
    ("Cross-trial amyloid extraction", "Imbimbo BP et al. Increases in amyloid-beta42 slow cognitive and clinical decline in Alzheimer's disease trials. Brain. 2024;147:3513-3526. https://academic.oup.com/brain/article/147/10/3513/7754406"),
    ("Gantenerumab", "Bateman RJ et al. Two Phase 3 Trials of Gantenerumab in Early Alzheimer's Disease. New England Journal of Medicine. 2023. https://doi.org/10.1056/NEJMoa2304430"),
    ("Donanemab", "Sims JR et al. Donanemab in Early Symptomatic Alzheimer Disease: The TRAILBLAZER-ALZ 2 Randomized Clinical Trial. JAMA. 2023. https://doi.org/10.1001/jama.2023.13239"),
    ("Lecanemab", "van Dyck CH et al. Lecanemab in Early Alzheimer's Disease. New England Journal of Medicine. 2023;388:9-21. https://doi.org/10.1056/NEJMoa2212948")
]
st = Table([[p(a,"TableCell"),p(b,"TableCell")] for a,b in sources], colWidths=[38*mm,129*mm])
st.setStyle(TableStyle([("BACKGROUND",(0,0),(0,-1),PALE_TEAL),("GRID",(0,0),(-1,-1),0.25,GRID),("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4)]))
story.append(st)

story.append(PageBreak())
story.append(p("Appendix: scenario definitions and output map", "H1x"))
story.append(p("Workbook tabs", "H2x"))
story.append(p("README documents the protocol; Key Results gives the central estimates; All Outcomes includes every analysis/scenario combination; Raw Mean Differences gives clinical-scale effects; Meta-regression contains continuous clearance models; Amyloid Mapping records each Centiloid value and source; Reproduction Check compares reconstructed and supplied Cochrane results; Cleaned Rows contains the study-analysis rows and classifications; Sources records provenance.", "Bodyx"))
story.append(p("Reproducible code and derived data", "H2x"))
story.append(p("The accompanying ZIP package contains the R analysis script, cleaned analysis rows, amyloid mapping, all sensitivity results, raw-MD results, meta-regression results, reproduction checks, and figure files. The original supplied attachments are not duplicated in the ZIP.", "Bodyx"))
story.append(p("Scenario definitions", "H2x"))
scenrows = [
    (COCH, "All studies in the original Cochrane analysis row."),
    ("Biomarker-confirmed", "Trials included in Cochrane's PET/CSF-abnormal sensitivity analysis."),
    (PRIMARY, "Biomarker-confirmed plus approved-generation antibody plus documented >=10-Centiloid plaque reduction."),
    (CLEAR, "Any matched trial with placebo-adjusted plaque reduction of at least 10 Centiloids, regardless of approval."),
    (ACTIVE, "Lecanemab and donanemab trials only.")
]
sct=Table([[p(a,"TableCell"),p(b,"TableCell")] for a,b in scenrows],colWidths=[72*mm,95*mm])
sct.setStyle(TableStyle([("BACKGROUND",(0,0),(0,-1),PALE_TEAL),("GRID",(0,0),(-1,-1),0.25,GRID),("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4)]))
story.append(sct)

doc.build(story)
print(OUT)
