import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const results = JSON.parse(await fs.readFile(path.join(root, "work/results/analysis_results.json"), "utf8"));
const outputDir = path.join(root, "outputs");
const previewDir = path.join(root, "work/workbook_previews");
await fs.mkdir(outputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });

const wb = Workbook.create();
const colors = {
  navy: "#17324D", blue: "#2E5D8A", teal: "#16837A", pale: "#EAF2F8",
  paleTeal: "#E7F5F2", amber: "#F5B642", paleAmber: "#FFF5D9", red: "#B64545",
  grid: "#D8E0E8", ink: "#1D2733", muted: "#5B6775", white: "#FFFFFF"
};

function colName(n) {
  let s = "";
  while (n > 0) { n--; s = String.fromCharCode(65 + (n % 26)) + s; n = Math.floor(n / 26); }
  return s;
}

function addTitle(sheet, title, subtitle, endCol = 8) {
  sheet.showGridLines = false;
  sheet.getRange(`A1:${colName(endCol)}1`).merge();
  sheet.getRange("A1").values = [[title]];
  sheet.getRange("A1").format = { fill: colors.navy, font: { bold: true, color: colors.white, size: 18 }, rowHeight: 34, verticalAlignment: "center" };
  sheet.getRange(`A2:${colName(endCol)}2`).merge();
  sheet.getRange("A2").values = [[subtitle]];
  sheet.getRange("A2").format = { fill: colors.pale, font: { color: colors.muted, italic: true, size: 10 }, wrapText: true, rowHeight: 32, verticalAlignment: "center" };
}

function writeTable(sheet, startRow, rows, columns, tableName, widths = {}) {
  const headers = columns.map(c => c.label);
  const matrix = [headers, ...rows.map(r => columns.map(c => r[c.key] ?? null))];
  const endRow = startRow + matrix.length - 1;
  const endCol = columns.length;
  const range = sheet.getRange(`A${startRow}:${colName(endCol)}${endRow}`);
  range.values = matrix;
  sheet.getRange(`A${startRow}:${colName(endCol)}${startRow}`).format = {
    fill: colors.blue, font: { bold: true, color: colors.white }, wrapText: true,
    borders: { preset: "outside", style: "thin", color: colors.navy }, rowHeight: 28
  };
  if (rows.length) {
    sheet.getRange(`A${startRow + 1}:${colName(endCol)}${endRow}`).format = {
      font: { color: colors.ink, size: 9 }, verticalAlignment: "top",
      borders: { insideHorizontal: { style: "thin", color: colors.grid } }
    };
    const table = sheet.tables.add(`A${startRow}:${colName(endCol)}${endRow}`, true, tableName);
    table.style = "TableStyleMedium2";
    table.showBandedColumns = false;
  }
  columns.forEach((c, i) => {
    const letter = colName(i + 1);
    sheet.getRange(`${letter}${startRow + 1}:${letter}${endRow}`).format.numberFormat = c.format || "General";
    sheet.getRange(`${letter}:${letter}`).format.columnWidth = widths[c.key] || (c.format ? 13 : 18);
  });
  sheet.freezePanes.freezeRows(startRow);
  return { endRow, endCol };
}

// README / protocol
{
  const s = wb.worksheets.add("README");
  addTitle(s, "Anti-amyloid antibody reanalysis", "Reproducible reanalysis of Cochrane CD016297 following the criteria requested in Snyder et al. (2026).", 8);
  const sections = [
    ["Purpose", "Reproduce the supplied Cochrane analyses, then evaluate biomarker-confirmed and plaque-clearing trial subsets, unstandardized mean differences, and continuous amyloid-clearance moderation."],
    ["Primary response-conforming set", "EMERGE, ENGAGE, CLARITY AD, and TRAILBLAZER-ALZ 2: biomarker-confirmed enrollment; approved-generation antibody; documented placebo-adjusted amyloid PET reduction of at least 10 Centiloids."],
    ["Sensitivity sets", "Cochrane class pool; biomarker-confirmed trials; all trials with demonstrated >=10-Centiloid clearance; currently active agents (lecanemab and donanemab)."],
    ["Statistical model", "Inverse-variance random-effects meta-analysis with REML heterogeneity estimation. Hartung-Knapp inference is used for analyses with at least three studies; normal/Wald inference for one or two studies. Continuous moderator models use plaque reduction per 10 Centiloids."],
    ["Direction", "For ADAS-Cog and CDR-SB, negative MD/SMD favors antibody. For MMSE and activities-of-daily-living scales, positive MD/SMD favors antibody. For harms expressed as RR, values above 1 indicate more events with antibody."],
    ["Important limitation", "Amyloid PET values are aggregate trial-level estimates. Meta-regression is ecological, includes only trials with matched PET estimates, and cannot establish individual-level mediation or causality."],
    ["Reproduction check", "Cochrane point estimates were reproduced from the supplied row-level export; maximum absolute point-estimate difference was <0.00005. Some confidence intervals differ because software implementations of small-sample/HKSJ adjustments differ."],
    ["Not clinical guidance", "This is an evidence-synthesis reanalysis, not a clinical-practice guideline or an individualized benefit-risk recommendation."]
  ];
  s.getRange(`A4:B${3 + sections.length}`).values = sections;
  s.getRange(`A4:A${3 + sections.length}`).format = { fill: colors.paleTeal, font: { bold: true, color: colors.navy }, verticalAlignment: "top", wrapText: true };
  s.getRange(`B4:B${3 + sections.length}`).format = { font: { color: colors.ink }, wrapText: true, verticalAlignment: "top" };
  s.getRange(`A4:B${3 + sections.length}`).format.borders = { insideHorizontal: { style: "thin", color: colors.grid }, outside: { style: "thin", color: colors.grid } };
  s.getRange("A:A").format.columnWidth = 28;
  s.getRange("B:B").format.columnWidth = 98;
  s.getRange(`4:${3 + sections.length}`).format.rowHeight = 48;
}

// Key findings dashboard
{
  const s = wb.worksheets.add("Key Results");
  addTitle(s, "Key results at approximately 18 months", "Primary response-conforming estimates shown with Cochrane class-pool comparators.", 11);
  const keyIds = ["1.1", "2.1", "3.5", "3.6", "4.2", "4.7", "5.1", "6.1", "9.1"];
  const scenarios = ["Cochrane class pool", "Response primary: clearing approved-generation trials"];
  const data = results.outcome_sensitivities
    .filter(r => keyIds.includes(r.analysis_id) && scenarios.includes(r.scenario))
    .sort((a,b) => keyIds.indexOf(a.analysis_id) - keyIds.indexOf(b.analysis_id) || scenarios.indexOf(a.scenario) - scenarios.indexOf(b.scenario));
  const cols = [
    {key:"analysis_id",label:"ID"},{key:"outcome",label:"Outcome"},{key:"measure",label:"Measure"},{key:"scenario",label:"Scenario"},
    {key:"k",label:"Studies",format:"0"},{key:"estimate",label:"Estimate",format:"0.000"},{key:"ci_low",label:"95% CI low",format:"0.000"},
    {key:"ci_high",label:"95% CI high",format:"0.000"},{key:"p_value",label:"P value",format:"0.0000"},{key:"i2",label:"I² (%)",format:"0.0"}
  ];
  writeTable(s, 5, data, cols, "KeyResultsTable", {outcome:32,scenario:45,analysis_id:8,measure:10});
  s.getRange(`F6:H${5 + data.length}`).conditionalFormats.add("colorScale", { colors: ["#DCEFEA", "#FFFFFF", "#F8D7D7"], thresholds: ["min", "50%", "max"] });
  s.getRange("A25:K25").merge();
  s.getRange("A25").values = [["Interpretation: narrowing to clearing modern agents increases estimated efficacy but also concentrates ARIA and discontinuation risk. Clinical-scale differences remain below Cochrane's cited MCIDs; statistical significance is not equivalent to patient-perceived importance."]];
  s.getRange("A25").format = { fill: colors.paleAmber, font: { color: colors.ink, bold: true }, wrapText: true, rowHeight: 46, verticalAlignment: "center" };

  // Native chart driven by formula-linked helper cells.
  const raw = results.raw_mean_differences.filter(r => ["1.1","2.1"].includes(r.analysis_id) && scenarios.includes(r.scenario));
  s.getRange("A28:B28").values = [["Endpoint / scenario", "Raw MD"]];
  s.getRange("A29:B32").values = raw.map(r => [`${r.analysis_id} ${r.scenario === scenarios[0] ? "Cochrane" : "Response primary"}`, r.estimate]);
  s.getRange("A28:B32").format.font = { size: 9 };
  s.getRange("A:A").format.columnWidth = 34;
  s.getRange("B29:B32").format.numberFormat = "0.00";
  const chart = s.charts.add("bar", s.getRange("A28:B32"));
  chart.title = "Raw mean differences: Cochrane vs response primary";
  chart.hasLegend = true;
  chart.xAxis = { axisType: "textAxis", textStyle: { fontSize: 9 } };
  chart.yAxis = { numberFormatCode: "0.00" };
  chart.setPosition("E28", "K44");
}

// Full sensitivity results
{
  const s = wb.worksheets.add("All Outcomes");
  addTitle(s, "All clinical outcome sensitivity analyses", "Every primary Cochrane analysis group (1-9) re-estimated across available response-conforming scenarios.", 12);
  const cols = [
    {key:"analysis_id",label:"ID"},{key:"outcome",label:"Outcome"},{key:"measure",label:"Measure"},{key:"scenario",label:"Scenario"},
    {key:"k",label:"k",format:"0"},{key:"estimate",label:"Estimate",format:"0.000"},{key:"ci_low",label:"CI low",format:"0.000"},
    {key:"ci_high",label:"CI high",format:"0.000"},{key:"p_value",label:"P value",format:"0.0000"},{key:"tau2",label:"Tau²",format:"0.000"},{key:"i2",label:"I² (%)",format:"0.0"}
  ];
  writeTable(s, 4, results.outcome_sensitivities, cols, "AllOutcomesTable", {outcome:34,scenario:48,analysis_id:8,measure:10});
}

{
  const s = wb.worksheets.add("Raw Mean Differences");
  addTitle(s, "Unstandardized mean differences", "Raw clinical-scale units calculated when arm means, SDs, and sample sizes were available in the Cochrane export.", 12);
  const cols = [
    {key:"analysis_id",label:"ID"},{key:"outcome",label:"Outcome"},{key:"scenario",label:"Scenario"},{key:"k",label:"k",format:"0"},
    {key:"estimate",label:"MD",format:"0.000"},{key:"ci_low",label:"CI low",format:"0.000"},{key:"ci_high",label:"CI high",format:"0.000"},
    {key:"p_value",label:"P value",format:"0.0000"},{key:"tau2",label:"Tau²",format:"0.000"},{key:"i2",label:"I² (%)",format:"0.0"}
  ];
  writeTable(s, 4, results.raw_mean_differences, cols, "RawMDTable", {outcome:34,scenario:48,analysis_id:8});
}

{
  const s = wb.worksheets.add("Meta-regression");
  addTitle(s, "Continuous amyloid-clearance sensitivity", "Random-effects trial-level meta-regression; slope is the clinical effect per additional 10-Centiloid plaque reduction.", 12);
  const cols = [
    {key:"outcome",label:"Outcome"},{key:"measure",label:"Measure"},{key:"k",label:"k",format:"0"},
    {key:"intercept",label:"Intercept",format:"0.000"},{key:"slope_per_10cl",label:"Slope / 10 CL",format:"0.000"},
    {key:"slope_ci_low",label:"Slope CI low",format:"0.000"},{key:"slope_ci_high",label:"Slope CI high",format:"0.000"},
    {key:"slope_p",label:"Slope P",format:"0.0000"},{key:"tau2",label:"Tau²",format:"0.000"},{key:"i2",label:"I² (%)",format:"0.0"}
  ];
  writeTable(s, 4, results.meta_regressions, cols, "MetaRegressionTable", {outcome:34,measure:10});
  s.getRange("A13:J15").merge();
  s.getRange("A13").values = [["Caution: these are aggregate-data, trial-level associations. They are sensitive to the small number of matched trials, PET measurement choices, dose/time matching, and ecological bias. They do not establish that amyloid reduction mediates individual clinical benefit."]];
  s.getRange("A13").format = { fill: colors.paleAmber, font: { color: colors.ink, bold: true }, wrapText: true, verticalAlignment: "center" };
}

{
  const s = wb.worksheets.add("Amyloid Mapping");
  addTitle(s, "Trial-level amyloid PET mapping", "Placebo-adjusted Centiloid change used for clearance classification and continuous moderation; negative values indicate plaque reduction.", 8);
  const cols = [
    {key:"Study",label:"Cochrane study"},{key:"amyloid_change_cl",label:"Amyloid change (CL)",format:"0.00"},
    {key:"amyloid_source",label:"Source"},{key:"mapping_note",label:"Mapping note"}
  ];
  writeTable(s, 4, results.amyloid_mapping, cols, "AmyloidMappingTable", {Study:30,amyloid_change_cl:20,amyloid_source:26,mapping_note:58});
}

{
  const s = wb.worksheets.add("Reproduction Check");
  addTitle(s, "Cochrane reproduction check", "Comparison of reconstructed class-pool estimates with the supplied Cochrane overall-estimate export.", 12);
  const cols = [
    {key:"analysis_id",label:"ID"},{key:"outcome",label:"Outcome"},{key:"measure",label:"Measure"},{key:"k",label:"k",format:"0"},
    {key:"estimate",label:"Reproduced",format:"0.000000"},{key:"cochrane_estimate",label:"Cochrane",format:"0.000000"},
    {key:"abs_difference",label:"Abs difference",format:"0.000000"},{key:"ci_low",label:"Repro CI low",format:"0.000"},
    {key:"ci_high",label:"Repro CI high",format:"0.000"},{key:"cochrane_ci_low",label:"Cochrane CI low",format:"0.000"},
    {key:"cochrane_ci_high",label:"Cochrane CI high",format:"0.000"}
  ];
  writeTable(s, 4, results.reproduction, cols, "ReproductionTable", {outcome:34,analysis_id:8,measure:10});
}

{
  const s = wb.worksheets.add("Cleaned Rows");
  addTitle(s, "Cleaned analysis rows", "Study-level rows from the supplied Cochrane analysis package with derived variances and response-conforming classifications.", 14);
  const keys = ["analysis_id","Analysis.name","Subgroup","Study","Study.year","Mean","CI.start","CI.end","Experimental.N","Control.N","yi","vi","amyloid_change_cl","biomarker_confirmed","approved_generation","active_2026","demonstrated_clearance","response_primary"];
  const cols = keys.map(k => ({ key:k, label:k.replaceAll("."," "), format: ["Mean","CI.start","CI.end","yi","vi","amyloid_change_cl"].includes(k) ? "0.0000" : undefined }));
  writeTable(s, 4, results.cleaned_rows, cols, "CleanedRowsTable", {"Analysis.name":34,Subgroup:18,Study:30,analysis_id:8});
}

{
  const s = wb.worksheets.add("Sources");
  addTitle(s, "Sources and provenance", "Primary supplied files and external trial-level amyloid sources used in this package.", 8);
  const sourceRows = [
    ["Cochrane review", "Amyloid-beta-targeting monoclonal antibodies for MCI or mild dementia due to Alzheimer's disease (CD016297), 2026", "Supplied PDF and data package"],
    ["Researcher response", "Snyder HM et al. Recent Cochrane review has serious flaws. Alzheimer's & Dementia. 2026;22(7).", "https://doi.org/10.1002/alz.71696"],
    ["Amyloid mapping", "Imbimbo BP et al. Increases in amyloid-beta42 slow cognitive and clinical decline in Alzheimer's disease trials. Brain. 2024;147:3513-3526.", "https://academic.oup.com/brain/article/147/10/3513/7754406"],
    ["GRADUATE PET", "Bateman RJ et al. Two Phase 3 Trials of Gantenerumab in Early Alzheimer's Disease. N Engl J Med. 2023.", "https://doi.org/10.1056/NEJMoa2304430"],
    ["Donanemab trial", "Sims JR et al. Donanemab in Early Symptomatic Alzheimer Disease: TRAILBLAZER-ALZ 2. JAMA. 2023.", "https://doi.org/10.1001/jama.2023.13239"],
    ["Lecanemab trial", "van Dyck CH et al. Lecanemab in Early Alzheimer's Disease. N Engl J Med. 2023;388:9-21.", "https://doi.org/10.1056/NEJMoa2212948"]
  ];
  s.getRange("A4:C10").values = [["Role","Citation","URL / provenance"], ...sourceRows];
  s.getRange("A4:C4").format = { fill: colors.blue, font: { bold:true, color:colors.white } };
  s.getRange("A5:C10").format = { wrapText:true, verticalAlignment:"top", borders:{ insideHorizontal:{style:"thin",color:colors.grid} } };
  s.getRange("A:A").format.columnWidth = 22; s.getRange("B:B").format.columnWidth = 82; s.getRange("C:C").format.columnWidth = 68;
  s.getRange("5:10").format.rowHeight = 46;
}

// Compact verification and previews.
const inspect = await wb.inspect({ kind: "sheet,table", maxChars: 6000, tableMaxRows: 4, tableMaxCols: 8 });
await fs.writeFile(path.join(previewDir, "inspect.ndjson"), inspect.ndjson || String(inspect));
const errors = await wb.inspect({ kind: "match", searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A", options: { useRegex: true, maxResults: 300 }, summary: "final formula error scan" });
await fs.writeFile(path.join(previewDir, "formula_errors.ndjson"), errors.ndjson || String(errors));
for (const sheetName of ["README", "Key Results", "All Outcomes", "Raw Mean Differences", "Meta-regression", "Amyloid Mapping", "Reproduction Check", "Cleaned Rows", "Sources"]) {
  const preview = await wb.render({ sheetName, autoCrop: "all", scale: 1, format: "png" });
  await fs.writeFile(path.join(previewDir, `${sheetName.replaceAll(" ", "_")}.png`), new Uint8Array(await preview.arrayBuffer()));
}

const output = await SpreadsheetFile.exportXlsx(wb);
await output.save(path.join(outputDir, "alzheimers_antibody_reanalysis.xlsx"));
console.log(JSON.stringify({ output: path.join(outputDir, "alzheimers_antibody_reanalysis.xlsx"), sheets: 9 }));
