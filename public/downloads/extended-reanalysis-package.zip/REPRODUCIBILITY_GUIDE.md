# Reproducibility guide: extended reanalysis

This document describes how every file in the extended reproducibility archive was generated. The extended package is a second-stage analysis: it consumes the cleaned primary rows and raw mean-difference table from the primary package, adds a transparent trial/agent annotation map, and writes additional exploratory analyses. The original Cochrane source export is not redistributed.

## 1. Pipeline and required hand-off

```text
primary code/reanalysis.R
  └─ cleaned_analysis_rows.csv + raw_mean_difference_results.csv
        │
        ▼
code/extended_reanalysis.R
  annotate agents, target classes, termination and biomarker status
  → individual-agent, termination, target-class, safety, MID, moderator,
    influence, benefit-harm, percent-slowing and QC tables
        │
        ├── code/extended_build_workbook.mjs → reports/*.xlsx
        └── code/extended_build_report.py   → reports/*_report.pdf
```

The two files in `work/results/` are the explicit hand-off from the primary package. They must be generated from the same primary source snapshot if a fully reproducible chain is desired. The extended script does not silently re-read the Cochrane export.

## 2. Rerun instructions

From the unpacked extended archive root (or the corresponding project root):

```sh
# First create the two required hand-off files with the primary package.
Rscript work/package/code/reanalysis.R

# Then run the extension.
Rscript work/extended_package/code/extended_reanalysis.R
node work/extended_package/code/extended_build_workbook.mjs
python3 work/extended_package/code/extended_build_report.py
```

The scripts use `root <- normalizePath(".")`, so paths are relative to the directory in which they are launched. In the packaged project, the primary hand-off is at `work/results/`; if you run a standalone copy, place the two CSVs there or edit `in_dir` at the top of the script. The R dependencies are `metafor`, `dplyr`, `readr`, `tidyr`, and `ggplot2`; `jsonlite` is optional for the JSON bundle. The builders require the original Node/document runtime and Python `reportlab`. Record R, Node, Python, and package versions because no lockfile is included.

## 3. What the extension adds

`trial_map` in the R script is an explicit, inspectable annotation table. It reconstructs antibody identity when a Cochrane subgroup cell is blank and records target class/detail, termination status/reason, biomarker status, and source note. The script then derives futility and any-early-termination flags, study year, and a five-year time trend.

All models use inverse-variance random effects with REML and Hartung–Knapp inference for k ≥ 3, Wald inference for k ≤ 2, and a DerSimonian–Laird fallback only when a sparse REML fit fails. Dichotomous outcomes are modeled as log RR; absolute safety is active minus placebo risk difference. The MID analysis is a compatibility display, not a claim that a cited threshold is a universal decision rule. Agent, target-class, moderator, and influence analyses are exploratory and unadjusted for multiplicity.

## 4. Complete output manifest

Every table below is written by the `outputs` list near the end of `extended_reanalysis.R` as a CSV in `work/extended_results/`. The same named objects are bundled into `extended_results.json` when `jsonlite` is available.

| File | Generation and interpretation |
|---|---|
| `trial_annotations.csv` | The explicit `trial_map`; the audit trail for agent, target class, termination, biomarker, and source coding. |
| `agent_results.csv` | Random-effects estimate for every outcome × antibody, with k, CI, p, tau², I², and prediction interval when estimable. |
| `raw_agent_results.csv` | The same antibody-specific grid using unstandardized arm-level mean differences where complete arm data exist. |
| `agent_interactions.csv` | Omnibus moderator tests for between-antibody differences when at least two antibodies and residual degrees of freedom are available. |
| `termination_sensitivities.csv` | Primary-scale results under Cochrane class pool, exclusion of futility-terminated trials, and exclusion of all early-terminated trials. |
| `raw_termination_sensitivities.csv` | The same termination scenarios on raw mean differences. |
| `target_class_results.csv` | Outcome estimates grouped by predominant binding/target class; categories are biologic simplifications, not mutually exclusive molecular mechanisms. |
| `leave_one_agent_out.csv` | Influence sensitivity after removing each antibody from the class pool. |
| `absolute_safety.csv` | Agent-specific absolute risk differences, CI, excess events per 1,000, and NNH/NNTB fields for the safety outcomes. |
| `absolute_safety_scenarios.csv` | Absolute safety under the termination/selection scenarios. |
| `mid_compatibility.csv` | Whether the raw clinical-effect CI crosses the ADAS-Cog or CDR-SB thresholds cited by the Cochrane review; it does not endorse those thresholds. |
| `moderator_results.csv` | Trial-level moderators, including ARIA-E excess risk as an indirect functional-unblinding proxy and study-year trend, where estimable. |
| `benefit_harm.csv` | Side-by-side agent-specific ADAS-Cog/CDR-SB effects and ARIA-E/discontinuation excess risk; no composite utility score is calculated. |
| `percent_slowing.csv` | Trial-level raw clinical differences converted to percent slowing relative to placebo decline when the required baseline/change fields exist. |
| `quality_control.csv` | Counts and checks for missing annotations, duplicate rows, and other expected data-integrity conditions printed by the script. |
| `annotated_rows.csv` | The primary cleaned rows after joining the full trial annotation map and derived termination/year fields. |
| `extended_results.json` | Machine-readable bundle containing all of the CSV objects above. |

## 5. Figures and presentation files

The script generates `figures/individual_antibody_efficacy.png` (ADAS-Cog and CDR-SB agent estimates), `absolute_aria_e_by_antibody.png` (absolute ARIA-E excess per 1,000), and `benefit_harm_matrix.png` (separate benefit and harm dimensions). `extended_build_workbook.mjs` reads `extended_results.json` and writes the formatted workbook in `reports/`; `extended_build_report.py` reads that JSON plus the PNGs and writes the PDF report. These builders only format and summarize already-generated tables.

## 6. Audit cautions

Termination status, target class, and biomarker status are annotations based on the cited Cochrane study descriptions and references; they are not newly abstracted individual-participant data. ARIA-E risk as a proxy for functional unblinding is indirect. Agent comparisons are cross-trial, not head-to-head randomized contrasts, and sparse subgroup estimates can be unstable. Keep the primary package’s source checksum, this archive’s version, and `sessionInfo()` with any rerun.
