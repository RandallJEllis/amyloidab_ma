# Extended anti-amyloid antibody reanalysis

This archive extends the original response-conforming reanalysis of Cochrane CD016297. It investigates additional empirical criticisms raised by Snyder et al. (2026): individual-antibody effects, failed or prematurely terminated trials, biological target class, absolute rather than relative safety effects, MID/MCID compatibility, possible functional unblinding, and class-estimate influence.

## Principal analyses

- Separate estimates for aducanumab, bapineuzumab, crenezumab, donanemab, gantenerumab, lecanemab, and solanezumab.
- Omnibus between-antibody moderator tests when residual degrees of freedom permitted.
- Exclusion of the six trials Cochrane classified as terminated for futility.
- Exclusion of all nine trials Cochrane classified as terminated early.
- Predominant amyloid-target classes: soluble monomer, soluble aggregate-preferring, aggregated/fibrillar, and pyroglutamate plaque.
- Agent-specific risk differences, excess events per 1,000, and NNH/NNTB when the 95% confidence interval excludes zero.
- Compatibility of raw clinical-effect confidence intervals with the ADAS-Cog and CDR-SB thresholds cited by Cochrane.
- Trial-level meta-regression using ARIA-E excess risk as an indirect functional-unblinding proxy.
- Sparse moderator models and leave-one-antibody-out influence analyses.

## Key findings

- Lecanemab and donanemab individually favored treatment on ADAS-Cog and CDR-SB, but formal between-antibody interaction tests were underpowered and nonsignificant.
- Excluding futility-terminated trials did not materially change ADAS-Cog and only modestly increased the CDR-SB effect.
- Any ARIA-E excess risk was approximately 326 per 1,000 for aducanumab, 220 per 1,000 for donanemab, and 109 per 1,000 for lecanemab in the supplied contrasts.
- At 18 months, the upper 95% confidence limits remained below the short-horizon 2-point ADAS-Cog and 1-point CDR-SB MCI benchmarks cited by Cochrane. This is a sensitivity analysis, not endorsement of those thresholds.
- Trial-level ARIA-E risk difference was not associated with ADAS-Cog, MMSE, or CDR-SB effects. The analysis is an indirect and underpowered test of functional unblinding.

## Directory structure

- `reports/`: final PDF report and Excel workbook.
- `code/extended_reanalysis.R`: statistical analysis.
- `code/extended_build_report.py`: PDF report builder.
- `code/extended_build_workbook.mjs`: workbook builder using `@oai/artifact-tool`.
- `work/results/`: two base tables required by the extended analysis.
- `work/extended_results/`: complete result CSVs, JSON, and figures.
- `REPRODUCIBILITY_GUIDE.md`: detailed lineage for every extended result, including the base tables consumed from the primary package.

For the complete provenance and output manifest, start with [`REPRODUCIBILITY_GUIDE.md`](REPRODUCIBILITY_GUIDE.md).

Run `Rscript code/extended_reanalysis.R` from the unpacked archive root. The builders expect the bundled Codex document runtime and should also be run from the archive root.

## Statistical conventions

Inverse-variance random-effects meta-analysis used REML heterogeneity estimation and Hartung-Knapp inference for analyses with at least three studies; one- and two-study analyses used Wald inference. A DerSimonian-Laird fallback was used only for sparse subgroups in which REML did not converge. Dichotomous outcomes were analyzed on the log-risk-ratio scale. Absolute safety estimates used risk differences calculated from events and randomized denominators.

All new interaction, target-class, moderator, and influence analyses are exploratory and unadjusted for multiplicity. Trial-level meta-regression is ecological and cannot establish individual-level mediation or causation.

## Sources

- Cochrane CD016297: https://doi.org/10.1002/14651858.CD016297
- Snyder et al. response: https://doi.org/10.1002/alz.71696
- Target-class background: https://pmc.ncbi.nlm.nih.gov/articles/PMC12047478/
- MID rapid review cited by Cochrane: https://doi.org/10.1002/alz.13770
- Meaningful-change analysis cited by Cochrane: https://doi.org/10.14283/jpad.2022.102
- Prior Centiloid mapping source: https://academic.oup.com/brain/article/147/10/3513/7754406

This package is an aggregate-data evidence-synthesis analysis, not individual medical advice or a clinical-practice guideline.
