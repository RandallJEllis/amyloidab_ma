import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const data = JSON.parse(await fs.readFile(path.join(root, "work/extended_results/extended_results.json"), "utf8"));
const outDir = path.join(root, "outputs");
const previewDir = path.join(root, "work/extended_workbook_previews");
await fs.mkdir(outDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });

const wb = Workbook.create();
const C = {navy:"#17324D",blue:"#2E5D8A",teal:"#16837A",pale:"#EAF2F8",paleTeal:"#E7F5F2",amber:"#FFF5D9",red:"#B64545",grid:"#D8E0E8",ink:"#1D2733",muted:"#5B6775",white:"#FFFFFF"};

function col(n){let s="";while(n){n--;s=String.fromCharCode(65+n%26)+s;n=Math.floor(n/26);}return s;}
function title(s,t,sub,end=10){
  s.showGridLines=false;
  s.getRange(`A1:${col(end)}1`).merge(); s.getRange("A1").values=[[t]];
  s.getRange("A1").format={fill:C.navy,font:{bold:true,color:C.white,size:18},rowHeight:34,verticalAlignment:"center"};
  s.getRange(`A2:${col(end)}2`).merge(); s.getRange("A2").values=[[sub]];
  s.getRange("A2").format={fill:C.pale,font:{color:C.muted,italic:true,size:10},wrapText:true,rowHeight:32,verticalAlignment:"center"};
}
function table(s,row,rows,columns,name,widths={}){
  const matrix=[columns.map(x=>x.label),...rows.map(r=>columns.map(x=>r[x.key]??null))];
  const er=row+matrix.length-1, ec=columns.length;
  s.getRange(`A${row}:${col(ec)}${er}`).values=matrix;
  s.getRange(`A${row}:${col(ec)}${row}`).format={fill:C.blue,font:{bold:true,color:C.white},wrapText:true,rowHeight:28,borders:{preset:"outside",style:"thin",color:C.navy}};
  if(rows.length){
    s.getRange(`A${row+1}:${col(ec)}${er}`).format={font:{color:C.ink,size:9},verticalAlignment:"top",borders:{insideHorizontal:{style:"thin",color:C.grid}}};
    const t=s.tables.add(`A${row}:${col(ec)}${er}`,true,name);t.style="TableStyleMedium2";
  }
  columns.forEach((x,i)=>{const l=col(i+1);s.getRange(`${l}${row+1}:${l}${er}`).format.numberFormat=x.format||"General";s.getRange(`${l}:${l}`).format.columnWidth=widths[x.key]||(x.format?13:20);});
  s.freezePanes.freezeRows(row);
  return {er,ec};
}

// README
{
  const s=wb.worksheets.add("README"); title(s,"Extended anti-amyloid antibody reanalysis","Companion workbook for the additional criticisms raised in Snyder et al. (2026).",8);
  const rows=[
    ["Purpose","Extend the prior plaque-clearance package with individual-drug, trial-termination, target-class, absolute-harm, MID compatibility, influence, and functional-unblinding-proxy analyses."],
    ["Primary source","Cochrane CD016297 supplied review and row-level analysis package."],
    ["Models","Inverse-variance random effects; REML with Hartung-Knapp for k>=3, Wald for k<=2. DL fallback only for sparse nonconvergence."],
    ["Termination coding","Cochrane reports six futility terminations, two symptomatic ARIA-E terminations, and one unexplained termination. The trial map reconciles exactly."],
    ["Target classes","Predominant binding preference only: soluble monomer; soluble aggregate-preferring; aggregated/fibrillar; pyroglutamate plaque. Categories overlap biologically."],
    ["MID analysis","Uses only ADAS-Cog and CDR-SB thresholds cited by Cochrane. It does not endorse them or treat them as a guideline decision threshold."],
    ["Absolute safety","Risk difference is active minus placebo. Positive values are excess harm. NNH/NNTB is displayed only when the 95% CI excludes zero."],
    ["Multiplicity","All new interactions and moderators are exploratory and unadjusted for multiplicity."],
    ["Scope","Aggregate-data evidence synthesis, not individual-level mediation, a head-to-head comparison, or clinical guidance."]
  ];
  s.getRange(`A4:B${3+rows.length}`).values=rows;
  s.getRange(`A4:A${3+rows.length}`).format={fill:C.paleTeal,font:{bold:true,color:C.navy},wrapText:true,verticalAlignment:"top"};
  s.getRange(`B4:B${3+rows.length}`).format={wrapText:true,verticalAlignment:"top",font:{color:C.ink}};
  s.getRange(`A4:B${3+rows.length}`).format.borders={insideHorizontal:{style:"thin",color:C.grid},outside:{style:"thin",color:C.grid}};
  s.getRange("A:A").format.columnWidth=29;s.getRange("B:B").format.columnWidth=98;s.getRange(`4:${3+rows.length}`).format.rowHeight=46;
}

// Key findings with a native chart.
{
  const s=wb.worksheets.add("Key Findings"); title(s,"Key findings","Treatment-specific clinical effects and absolute harms from the extended reanalysis.",12);
  const rows=[
    ["ADAS-Cog interaction P",0.432782,"No statistically established between-antibody interaction; low power."],
    ["CDR-SB interaction P",0.394905,"No statistically established between-antibody interaction; low power."],
    ["Lecanemab ADAS-Cog MD",-1.44,"95% CI -2.27 to -0.61 points."],
    ["Donanemab ADAS-Cog MD",-1.35,"95% CI -2.20 to -0.50 points."],
    ["Lecanemab ARIA-E excess / 1,000",109.1,"95% CI 85.9 to 132.4; NNH 9.2."],
    ["Donanemab ARIA-E excess / 1,000",219.7,"95% CI 189.6 to 249.9; NNH 4.6."],
    ["Aducanumab ARIA-E excess / 1,000",326.3,"95% CI 296.4 to 356.3; NNH 3.1."],
    ["ADAS-Cog SMD after excluding futility",-0.1089,"Nearly unchanged from class pool -0.1106."],
    ["CDR-SB SMD after excluding futility",-0.1475,"Numerically larger; 95% CI includes zero."]
  ];
  s.getRange("A5:C14").values=[["Finding","Value","Interpretation"],...rows];
  s.getRange("A5:C5").format={fill:C.blue,font:{bold:true,color:C.white}};
  s.getRange("A6:C14").format={borders:{insideHorizontal:{style:"thin",color:C.grid}},verticalAlignment:"top"};
  s.getRange("A:A").format.columnWidth=42;s.getRange("B:B").format.columnWidth=18;s.getRange("C:C").format.columnWidth=66;
  s.getRange("B6:B14").format.numberFormat="0.0000";
  s.getRange("A17:B17").values=[["Agent","ARIA-E excess / 1,000"]];
  s.getRange("A18:B20").values=[["Aducanumab",326.344],["Donanemab",219.733],["Lecanemab",109.113]];
  const chart=s.charts.add("bar",s.getRange("A17:B20")); chart.title="Absolute ARIA-E excess risk by antibody";chart.hasLegend=false;chart.xAxis={axisType:"textAxis",textStyle:{fontSize:9}};chart.yAxis={numberFormatCode:"0"};chart.setPosition("E17","L33");
  s.getRange("A36:L36").merge();s.getRange("A36").values=[["Interpretation: individual-drug estimates and absolute safety are more decision-relevant than a single class average. Formal interactions remain underpowered, and no composite net-benefit ranking is imposed."]];
  s.getRange("A36").format={fill:C.amber,font:{bold:true,color:C.ink},wrapText:true,rowHeight:44,verticalAlignment:"center"};
}

// Benefit-harm matrix
{
  const s=wb.worksheets.add("Benefit-Harm"); title(s,"Benefit-harm matrix","Separate clinical and safety dimensions; no patient-preference weights or composite utility.",12);
  const cols=[{key:"agent",label:"Agent"},{key:"adas_md",label:"ADAS-Cog MD",format:"0.00"},{key:"adas_ci_low",label:"ADAS CI low",format:"0.00"},{key:"adas_ci_high",label:"ADAS CI high",format:"0.00"},{key:"cdr_sb_md",label:"CDR-SB MD",format:"0.00"},{key:"cdr_ci_low",label:"CDR CI low",format:"0.00"},{key:"cdr_ci_high",label:"CDR CI high",format:"0.00"},{key:"aria_e_excess_per_1000",label:"ARIA-E excess / 1,000",format:"0.0"},{key:"discontinuation_excess_per_1000",label:"Discontinuation excess / 1,000",format:"0.0"}];
  table(s,5,data.benefit_harm,cols,"BenefitHarmTable",{agent:18});
  s.getRange("A11:I13").merge();s.getRange("A11").values=[["Caution: these are cross-trial, aggregate comparisons. They are not randomized head-to-head contrasts and do not account for APOE genotype, MRI risk, treatment burden, cost, or patient preferences."]];
  s.getRange("A11").format={fill:C.amber,font:{bold:true,color:C.ink},wrapText:true,verticalAlignment:"center"};
}

{
  const s=wb.worksheets.add("Agent Results"); title(s,"Individual-antibody results","All Cochrane outcome settings estimated separately by antibody.",14);
  const cols=[{key:"analysis_id",label:"ID"},{key:"outcome",label:"Outcome"},{key:"measure",label:"Measure"},{key:"agent",label:"Agent"},{key:"k",label:"k",format:"0"},{key:"estimate",label:"Estimate",format:"0.000"},{key:"ci_low",label:"CI low",format:"0.000"},{key:"ci_high",label:"CI high",format:"0.000"},{key:"p_value",label:"P",format:"0.0000"},{key:"i2",label:"I² (%)",format:"0.0"},{key:"pi_low",label:"Prediction low",format:"0.000"},{key:"pi_high",label:"Prediction high",format:"0.000"}];
  table(s,4,data.agent_results,cols,"AgentResultsTable",{outcome:36,agent:18,analysis_id:8,measure:10});
}

{
  const s=wb.worksheets.add("Raw Agent MD"); title(s,"Raw mean differences by antibody","Reconstructed from arm means, SDs, and sample sizes where the same clinical scale was used.",13);
  const cols=[{key:"analysis_id",label:"ID"},{key:"outcome",label:"Outcome"},{key:"agent",label:"Agent"},{key:"k",label:"k",format:"0"},{key:"estimate",label:"MD",format:"0.000"},{key:"ci_low",label:"CI low",format:"0.000"},{key:"ci_high",label:"CI high",format:"0.000"},{key:"p_value",label:"P",format:"0.0000"},{key:"i2",label:"I² (%)",format:"0.0"}];
  table(s,4,data.raw_agent_results,cols,"RawAgentMDTable",{outcome:36,agent:18,analysis_id:8});
}

// Absolute safety with formula-driven presentation columns.
{
  const s=wb.worksheets.add("Absolute Safety"); title(s,"Absolute safety by antibody","Risk differences are active minus placebo. Positive values indicate excess events with treatment.",16);
  const rows=data.absolute_safety;
  const cols=[{key:"analysis_id",label:"ID"},{key:"outcome",label:"Outcome"},{key:"agent",label:"Agent"},{key:"k",label:"k",format:"0"},{key:"estimate",label:"Risk difference",format:"0.0000"},{key:"ci_low",label:"RD CI low",format:"0.0000"},{key:"ci_high",label:"RD CI high",format:"0.0000"},{key:"active_events",label:"Active events",format:"0"},{key:"active_n",label:"Active N",format:"0"},{key:"control_events",label:"Control events",format:"0"},{key:"control_n",label:"Control N",format:"0"}];
  const {er}=table(s,4,rows,cols,"AbsoluteSafetyTable",{outcome:34,agent:18,analysis_id:8});
  s.getRange("L4:N4").values=[["Excess / 1,000","NNH/NNTB","Interpretation"]];s.getRange("L4:N4").format={fill:C.teal,font:{bold:true,color:C.white},wrapText:true};
  if(rows.length){
    s.getRange("L5").formulas=[["=E5*1000"]];s.getRange(`L5:L${er}`).fillDown();s.getRange(`L5:L${er}`).format.numberFormat="0.0";
    s.getRange("M5").formulas=[["=IF(AND(F5<=0,G5>=0),\"Indeterminate\",1/ABS(E5))"]];s.getRange(`M5:M${er}`).fillDown();s.getRange(`M5:M${er}`).format.numberFormat="0.0";
    s.getRange("N5").formulas=[["=IF(AND(F5<=0,G5>=0),\"CI crosses zero\",IF(E5>0,\"NNH\",\"NNTB\"))"]];s.getRange(`N5:N${er}`).fillDown();
    s.getRange(`L5:N${er}`).format={borders:{insideHorizontal:{style:"thin",color:C.grid}},verticalAlignment:"top"};
  }
  s.getRange("L:L").format.columnWidth=18;s.getRange("M:M").format.columnWidth=15;s.getRange("N:N").format.columnWidth=20;
}

{
  const s=wb.worksheets.add("Termination Sensitivity"); title(s,"Trial-termination sensitivities","Class pool compared with exclusions based on Cochrane-reported termination reasons.",13);
  const cols=[{key:"analysis_id",label:"ID"},{key:"outcome",label:"Outcome"},{key:"measure",label:"Measure"},{key:"scenario",label:"Scenario"},{key:"k",label:"k",format:"0"},{key:"estimate",label:"Estimate",format:"0.000"},{key:"ci_low",label:"CI low",format:"0.000"},{key:"ci_high",label:"CI high",format:"0.000"},{key:"p_value",label:"P",format:"0.0000"},{key:"i2",label:"I² (%)",format:"0.0"}];
  table(s,4,data.termination_sensitivities,cols,"TerminationTable",{outcome:36,scenario:42,analysis_id:8,measure:10});
}

{
  const s=wb.worksheets.add("MID Compatibility"); title(s,"MID and MCID compatibility","Short-horizon thresholds cited by Cochrane; sensitivity analysis only, not newly endorsed benchmarks.",13);
  const cols=[{key:"analysis_id",label:"ID"},{key:"outcome",label:"Outcome"},{key:"scenario",label:"Scenario"},{key:"k",label:"k",format:"0"},{key:"benefit_estimate",label:"Benefit",format:"0.00"},{key:"benefit_ci_low",label:"Benefit CI low",format:"0.00"},{key:"benefit_ci_high",label:"Benefit CI high",format:"0.00"},{key:"threshold_points",label:"Threshold",format:"0.0"},{key:"threshold_result",label:"Compatibility"},{key:"horizon_warning",label:"Horizon caution"}];
  table(s,4,data.mid_compatibility,cols,"MIDCompatibilityTable",{outcome:34,scenario:44,threshold_result:35,horizon_warning:46,analysis_id:8});
}

{
  const s=wb.worksheets.add("Target Classes"); title(s,"Biological target-class results","Predominant binding categories; several antibodies engage more than one amyloid species.",13);
  const cols=[{key:"analysis_id",label:"ID"},{key:"outcome",label:"Outcome"},{key:"measure",label:"Measure"},{key:"target_class",label:"Target class"},{key:"k",label:"k",format:"0"},{key:"estimate",label:"Estimate",format:"0.000"},{key:"ci_low",label:"CI low",format:"0.000"},{key:"ci_high",label:"CI high",format:"0.000"},{key:"p_value",label:"P",format:"0.0000"},{key:"i2",label:"I² (%)",format:"0.0"}];
  table(s,4,data.target_class_results,cols,"TargetClassTable",{outcome:36,target_class:34,analysis_id:8,measure:10});
}

{
  const s=wb.worksheets.add("Interaction Tests"); title(s,"Between-antibody interaction tests","Omnibus random-effects moderator tests when residual degrees of freedom were available.",12);
  const cols=[{key:"analysis_id",label:"ID"},{key:"outcome",label:"Outcome"},{key:"measure",label:"Measure"},{key:"k",label:"k",format:"0"},{key:"agents",label:"Agents",format:"0"},{key:"omnibus_qm",label:"QM",format:"0.000"},{key:"omnibus_df",label:"df",format:"0"},{key:"omnibus_p",label:"Interaction P",format:"0.0000"},{key:"residual_i2",label:"Residual I²",format:"0.0"},{key:"residual_tau2",label:"Residual tau²",format:"0.000"}];
  table(s,4,data.agent_interactions,cols,"InteractionTestsTable",{outcome:38,analysis_id:8,measure:10});
}

{
  const s=wb.worksheets.add("Moderator Models"); title(s,"Sparse exploratory moderator models","One moderator at a time; aggregate-data and unadjusted for multiplicity.",13);
  const cols=[{key:"analysis_id",label:"ID"},{key:"outcome",label:"Outcome"},{key:"measure",label:"Measure"},{key:"k",label:"k",format:"0"},{key:"moderator",label:"Moderator"},{key:"slope",label:"Slope",format:"0.0000"},{key:"slope_ci_low",label:"CI low",format:"0.0000"},{key:"slope_ci_high",label:"CI high",format:"0.0000"},{key:"slope_p",label:"P",format:"0.0000"},{key:"i2",label:"I² (%)",format:"0.0"}];
  table(s,4,data.moderator_results,cols,"ModeratorModelsTable",{outcome:34,moderator:52,analysis_id:8,measure:10});
}

{
  const s=wb.worksheets.add("Leave-One-Out"); title(s,"Leave-one-antibody-out influence","Each estimate omits all contrasts for one antibody; estimates are highly dependent.",12);
  const cols=[{key:"analysis_id",label:"ID"},{key:"outcome",label:"Outcome"},{key:"measure",label:"Measure"},{key:"omitted_agent",label:"Omitted antibody"},{key:"k",label:"k",format:"0"},{key:"estimate",label:"Estimate",format:"0.000"},{key:"ci_low",label:"CI low",format:"0.000"},{key:"ci_high",label:"CI high",format:"0.000"},{key:"p_value",label:"P",format:"0.0000"},{key:"i2",label:"I² (%)",format:"0.0"}];
  table(s,4,data.leave_one_agent_out,cols,"LeaveOneOutTable",{outcome:36,omitted_agent:20,analysis_id:8,measure:10});
}

{
  const s=wb.worksheets.add("Trial Annotations"); title(s,"Trial and antibody annotations","Status coding follows Cochrane; target classes summarize predominant binding preference.",12);
  const cols=[{key:"Study",label:"Study"},{key:"agent",label:"Antibody"},{key:"target_class",label:"Target class"},{key:"target_detail",label:"Target detail"},{key:"termination_status",label:"Termination status"},{key:"termination_reason",label:"Reason"},{key:"biomarker_status",label:"Biomarker requirement"},{key:"status_source",label:"Status source"}];
  table(s,4,data.trial_annotations,cols,"TrialAnnotationsTable",{Study:30,agent:18,target_class:31,target_detail:50,termination_status:21,termination_reason:22,biomarker_status:24,status_source:48});
}

{
  const s=wb.worksheets.add("Quality Control"); title(s,"Quality control","Classification reconciliation and workbook checks.",8);
  s.getRange(`A4:B${3+data.quality_control.length}`).values=[["Check","Value"],...data.quality_control.map(x=>[x.check,x.value])];
  s.getRange("A4:B4").format={fill:C.blue,font:{bold:true,color:C.white}};s.getRange(`A5:B${3+data.quality_control.length}`).format={borders:{insideHorizontal:{style:"thin",color:C.grid}}};
  s.getRange("A:A").format.columnWidth=55;s.getRange("B:B").format.columnWidth=16;s.getRange(`B5:B${3+data.quality_control.length}`).format.numberFormat="0";
  s.getRange("D4:E8").values=[["Derived check","Formula"],["Futility coding matches Cochrane",null],["All termination coding matches Cochrane",null],["Missing agent rows",null],["Missing termination rows",null]];
  s.getRange("D4:E4").format={fill:C.teal,font:{bold:true,color:C.white}};
  s.getRange("E5").formulas=[["=IF(B7=B9,\"PASS\",\"FAIL\")"]];
  s.getRange("E6").formulas=[["=IF(B8=B10,\"PASS\",\"FAIL\")"]];
  s.getRange("E7").formulas=[["=IF(B11=0,\"PASS\",\"FAIL\")"]];
  s.getRange("E8").formulas=[["=IF(B12=0,\"PASS\",\"FAIL\")"]];
  s.getRange("D:D").format.columnWidth=42;s.getRange("E:E").format.columnWidth=16;
}

{
  const s=wb.worksheets.add("Sources"); title(s,"Sources and provenance","URLs are included in plain text for auditability.",8);
  const rows=[
    ["Cochrane review and analysis package","Primary clinical and safety data; termination and MID discussion","https://doi.org/10.1002/14651858.CD016297"],
    ["Snyder et al. response","Criticisms operationalized in this extension","https://doi.org/10.1002/alz.71696"],
    ["Cummings et al. 2025","Predominant amyloid-species target classification","https://pmc.ncbi.nlm.nih.gov/articles/PMC12047478/"],
    ["Muir et al. 2024","MID rapid review cited by Cochrane","https://doi.org/10.1002/alz.13770"],
    ["Lansdall et al. 2023","Meaningful-change source cited by Cochrane","https://doi.org/10.14283/jpad.2022.102"],
    ["Imbimbo et al. 2024","Centiloid mapping used in prior package","https://academic.oup.com/brain/article/147/10/3513/7754406"]
  ];
  s.getRange("A4:C10").values=[["Source","Role","URL"],...rows];s.getRange("A4:C4").format={fill:C.blue,font:{bold:true,color:C.white}};s.getRange("A5:C10").format={wrapText:true,verticalAlignment:"top",borders:{insideHorizontal:{style:"thin",color:C.grid}}};
  s.getRange("A:A").format.columnWidth=32;s.getRange("B:B").format.columnWidth=65;s.getRange("C:C").format.columnWidth=72;s.getRange("5:10").format.rowHeight=42;
}

// Compact inspection, formula scan, and visual render of every sheet.
const inspect=await wb.inspect({kind:"sheet,table",maxChars:7000,tableMaxRows:4,tableMaxCols:8});
await fs.writeFile(path.join(previewDir,"inspect.ndjson"),inspect.ndjson||String(inspect));
const errors=await wb.inspect({kind:"match",searchTerm:"#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",options:{useRegex:true,maxResults:300},summary:"final formula error scan"});
await fs.writeFile(path.join(previewDir,"formula_errors.ndjson"),errors.ndjson||String(errors));
const names=["README","Key Findings","Benefit-Harm","Agent Results","Raw Agent MD","Absolute Safety","Termination Sensitivity","MID Compatibility","Target Classes","Interaction Tests","Moderator Models","Leave-One-Out","Trial Annotations","Quality Control","Sources"];
for(const n of names){const blob=await wb.render({sheetName:n,autoCrop:"all",scale:1,format:"png"});await fs.writeFile(path.join(previewDir,`${n.replaceAll(" ","_")}.png`),new Uint8Array(await blob.arrayBuffer()));}
const output=await SpreadsheetFile.exportXlsx(wb);await output.save(path.join(outDir,"alzheimers_antibody_extended_reanalysis.xlsx"));
console.log(JSON.stringify({output:path.join(outDir,"alzheimers_antibody_extended_reanalysis.xlsx"),sheets:names.length}));
