from __future__ import annotations

import json
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (
    BaseDocTemplate, Frame, PageTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, Image, KeepTogether
)

ROOT = Path(__file__).resolve().parent.parent
DATA = json.loads((ROOT / "work/extended_results/extended_results.json").read_text())
OUT = ROOT / "outputs/alzheimers_antibody_extended_reanalysis_report.pdf"
FIG = ROOT / "work/extended_results/figures"

NAVY = colors.HexColor("#17324D")
BLUE = colors.HexColor("#2E5D8A")
TEAL = colors.HexColor("#16837A")
RED = colors.HexColor("#B64545")
PALE = colors.HexColor("#EAF2F8")
PALE_TEAL = colors.HexColor("#E7F5F2")
AMBER = colors.HexColor("#FFF5D9")
GRID = colors.HexColor("#D8E0E8")
INK = colors.HexColor("#1D2733")
MUTED = colors.HexColor("#5B6775")

styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name="TitleWhite", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=22, leading=26, textColor=colors.white, spaceAfter=8))
styles.add(ParagraphStyle(name="SubWhite", parent=styles["Normal"], fontSize=10, leading=14, textColor=colors.HexColor("#DDE8F2")))
styles.add(ParagraphStyle(name="H1x", parent=styles["Heading1"], fontName="Helvetica-Bold", fontSize=17, leading=21, textColor=NAVY, spaceAfter=9))
styles.add(ParagraphStyle(name="H2x", parent=styles["Heading2"], fontName="Helvetica-Bold", fontSize=12.5, leading=16, textColor=BLUE, spaceBefore=7, spaceAfter=5))
styles.add(ParagraphStyle(name="Bodyx", parent=styles["BodyText"], fontName="Helvetica", fontSize=9.2, leading=13, textColor=INK, spaceAfter=7))
styles.add(ParagraphStyle(name="Smallx", parent=styles["BodyText"], fontName="Helvetica", fontSize=7.4, leading=9.5, textColor=INK))
styles.add(ParagraphStyle(name="Tinyx", parent=styles["BodyText"], fontName="Helvetica", fontSize=6.2, leading=7.7, textColor=INK))
styles.add(ParagraphStyle(name="Callout", parent=styles["BodyText"], fontName="Helvetica-Bold", fontSize=9.2, leading=13, textColor=NAVY, backColor=AMBER, borderPadding=8, spaceAfter=9))
styles.add(ParagraphStyle(name="Captionx", parent=styles["BodyText"], fontName="Helvetica-Oblique", fontSize=7.4, leading=9.5, textColor=MUTED, alignment=TA_CENTER, spaceAfter=7))
styles.add(ParagraphStyle(name="TableHead", parent=styles["BodyText"], fontName="Helvetica-Bold", fontSize=6.8, leading=8, textColor=colors.white))
styles.add(ParagraphStyle(name="TableCell", parent=styles["BodyText"], fontName="Helvetica", fontSize=6.7, leading=8.1, textColor=INK))


def header_footer(canvas, doc):
    canvas.saveState()
    width, _ = A4
    canvas.setStrokeColor(GRID)
    canvas.setLineWidth(.4)
    canvas.line(17 * mm, 14 * mm, width - 17 * mm, 14 * mm)
    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(MUTED)
    canvas.drawString(17 * mm, 10 * mm, "Extended anti-amyloid antibody reanalysis")
    canvas.drawRightString(width - 17 * mm, 10 * mm, f"Page {doc.page}")
    canvas.restoreState()


doc = BaseDocTemplate(str(OUT), pagesize=A4, leftMargin=17*mm, rightMargin=17*mm,
                      topMargin=20*mm, bottomMargin=17*mm,
                      title="Extended anti-amyloid antibody reanalysis")
frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="normal")
doc.addPageTemplates(PageTemplate(id="main", frames=frame, onPage=header_footer))


def p(text, style="Bodyx"):
    return Paragraph(text, styles[style])


def fnum(x, d=3):
    if x is None:
        return "NA"
    return f"{x:.{d}f}"


def find(rows, **conds):
    for row in rows:
        if all(row.get(k) == v for k, v in conds.items()):
            return row
    return None


def styled_table(rows, widths, header=BLUE, repeat=1, cell_style="TableCell"):
    table_rows = []
    for i, row in enumerate(rows):
        sty = "TableHead" if i == 0 else cell_style
        table_rows.append([p(str(v), sty) for v in row])
    t = Table(table_rows, colWidths=widths, repeatRows=repeat)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), header),
        ("GRID", (0,0), (-1,-1), .25, GRID),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, PALE]),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("LEFTPADDING", (0,0), (-1,-1), 4),
        ("RIGHTPADDING", (0,0), (-1,-1), 4),
        ("TOPPADDING", (0,0), (-1,-1), 3.5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 3.5),
    ]))
    return t


story = []

# Cover
cover = Table([[p("Extended reanalysis of anti-amyloid monoclonal antibody trials", "TitleWhite")],
               [p("Individual drugs, trial termination, biological target class, absolute harms, MID compatibility, and exploratory moderator analyses", "SubWhite")]],
              colWidths=[176*mm], rowHeights=[48*mm, 28*mm])
cover.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,-1), NAVY),
                           ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
                           ("LEFTPADDING", (0,0), (-1,-1), 13*mm),
                           ("RIGHTPADDING", (0,0), (-1,-1), 13*mm)]))
story += [Spacer(1, 25*mm), cover, Spacer(1, 13*mm),
          p("Purpose", "H1x"),
          p("This package investigates the additional empirical criticisms raised in Snyder et al. (2026) using the Cochrane CD016297 analysis export. It extends the prior plaque-clearance reanalysis without converting the evidence synthesis into a clinical-practice guideline or a single net-benefit judgment."),
          p("Headline", "H2x"),
          p("The data support treatment-specific reporting and absolute safety estimates. They do not establish statistically significant differences among antibodies, validate a single clinical-importance threshold, or prove that amyloid removal mediates individual benefit.", "Callout"),
          p("Prepared 14 August 2026. Aggregate-data meta-analysis; not individual medical guidance.", "Captionx"),
          PageBreak()]

# Executive summary
story += [p("1. Executive summary", "H1x")]
summary_rows = [
    ["Question", "Result", "Interpretation"],
    ["Do individual drugs differ?", "Lecanemab and donanemab individually favored treatment on ADAS-Cog and CDR-SB.", "Formal interaction tests were nonsignificant (ADAS-Cog P=0.433; CDR-SB P=0.395) and underpowered."],
    ["Do futility trials dilute efficacy?", "ADAS-Cog SMD was -0.111 class-wide, -0.109 after excluding futility trials, and -0.123 after excluding all early terminations.", "Little evidence that termination status alone explains the class estimate."],
    ["What are the absolute ARIA-E effects?", "Excess per 1,000: aducanumab 326, donanemab 220, lecanemab 109.", "Absolute risk differs materially by agent and is more useful clinically than a class RR alone."],
    ["Do effects reach cited MIDs?", "At 18 months, the upper 95% CI remained below the cited 2-point ADAS-Cog and 1-point CDR-SB MCI benchmarks.", "This is threshold compatibility, not proof of no patient value; thresholds were derived over shorter horizons."],
    ["Does ARIA-related unblinding explain efficacy?", "ARIA-E risk-difference moderation was not detected for ADAS-Cog, MMSE, or CDR-SB.", "The proxy is indirect and underpowered; absence of association does not eliminate functional unblinding."],
    ["Does target class explain effects?", "Patterns differed descriptively across target classes.", "Classes remain internally heterogeneous and strongly confounded with agent and trial era."],
]
story += [styled_table(summary_rows, [39*mm, 67*mm, 70*mm]), Spacer(1, 7*mm),
          p("The most defensible conclusion is treatment-specific: modern plaque-clearing antibodies produce small average clinical effects with substantial, agent-dependent imaging toxicity. The expanded analyses weaken simple class-wide interpretations but do not justify a causal or universal benefit-risk claim.", "Callout"),
          PageBreak()]

# Methods
story += [p("2. Methods", "H1x"),
          p("The supplied Cochrane row-level data were annotated by antibody, biological target class, biomarker requirement, publication year, and trial-termination status. Termination coding followed the Cochrane review, which reports six studies terminated for futility, two for symptomatic ARIA-E, and one without a reported reason. The annotation reconciled exactly to those totals."),
          p("Statistical approach", "H2x"),
          p("Random-effects inverse-variance meta-analysis used REML heterogeneity estimation and Hartung-Knapp inference for three or more studies; Wald inference was used for one or two studies. A DerSimonian-Laird fallback was used only when REML failed to converge in a sparse subgroup. Risk ratios were analyzed on the log scale. Raw mean differences were reconstructed from arm means, standard deviations, and sample sizes where available."),
          p("New analyses", "H2x")]
method_rows = [
    ["Analysis", "Operationalization"],
    ["Individual antibody", "Separate pooled estimates for seven antibodies; omnibus treatment-by-antibody moderator tests when residual degrees of freedom permitted."],
    ["Trial termination", "Class pool compared with exclusion of six futility-terminated trials and exclusion of all nine early-terminated trials."],
    ["Target class", "Soluble monomer, soluble aggregate-preferring, aggregated/fibrillar, and pyroglutamate plaque categories."],
    ["Absolute safety", "Risk difference, excess events per 1,000, and NNH/NNTB when the 95% CI did not cross zero."],
    ["MID compatibility", "CIs compared with ADAS-Cog 2/3/4-point and CDR-SB 1/2-point benchmarks cited by Cochrane; no threshold newly endorsed."],
    ["Functional unblinding proxy", "Trial-level efficacy regressed on excess ARIA-E risk per 10 percentage points."],
    ["Influence and moderation", "Leave-one-antibody-out analyses and sparse one-moderator models for biomarker confirmation, futility, publication year, and ARIA-E risk."],
]
story += [styled_table(method_rows, [45*mm, 131*mm]),
          p("Multiplicity", "H2x"),
          p("All new moderator, interaction, target-class, and leave-one-out analyses are exploratory. P values were not adjusted for multiplicity and should be read as descriptive measures of compatibility, not confirmatory tests."),
          PageBreak()]

# Individual drugs
story += [p("3. Individual-antibody efficacy", "H1x"),
          Image(str(FIG / "individual_antibody_efficacy.png"), width=176*mm, height=97*mm),
          p("Figure 1. Individual-antibody standardized effects. Single-trial estimates retain their trial-level normal confidence intervals; multi-trial antibody pools use the prespecified random-effects method.", "Captionx")]

agent_rows = [["Agent", "ADAS-Cog SMD (95% CI)", "CDR-SB SMD (95% CI)", "ADAS-Cog raw MD", "CDR-SB raw MD"]]
for agent in ["Aducanumab", "Bapineuzumab", "Crenezumab", "Donanemab", "Gantenerumab", "Lecanemab", "Solanezumab"]:
    a1 = find(DATA["agent_results"], analysis_id="1.1", agent=agent)
    a2 = find(DATA["agent_results"], analysis_id="2.1", agent=agent)
    r1 = find(DATA["raw_agent_results"], analysis_id="1.1", agent=agent)
    r2 = find(DATA["raw_agent_results"], analysis_id="2.1", agent=agent)
    def eff(x): return "NA" if not x else f"{fnum(x['estimate'])} ({fnum(x['ci_low'])}, {fnum(x['ci_high'])})"
    agent_rows.append([agent, eff(a1), eff(a2), eff(r1), eff(r2)])
story += [styled_table(agent_rows, [29*mm, 42*mm, 42*mm, 31*mm, 31*mm]),
          p("Lecanemab and donanemab each favored treatment on both central endpoints. Aducanumab was heterogeneous and imprecise, especially for CDR-SB. Nevertheless, formal omnibus interaction tests did not establish between-antibody differences: P=0.433 for ADAS-Cog and P=0.395 for CDR-SB. With seven drugs but only 13 and nine contrasts, respectively, these tests have little power and cannot be treated as evidence of equivalence."),
          PageBreak()]

# Termination
story += [p("4. Trial-termination sensitivity analyses", "H1x")]
term_rows = [["Endpoint", "Scenario", "k", "Estimate (95% CI)", "P", "I2"]]
for aid in ["1.1", "2.1", "3.5", "4.2", "4.7", "9.1"]:
    for scen in ["Cochrane class pool", "Exclude futility-terminated trials", "Exclude all early-terminated trials"]:
        r = find(DATA["termination_sensitivities"], analysis_id=aid, scenario=scen)
        if r:
            term_rows.append([r["outcome"], scen.replace("Exclude ", "Excl. "), str(r["k"]),
                              f"{fnum(r['estimate'])} ({fnum(r['ci_low'])}, {fnum(r['ci_high'])})",
                              fnum(r["p_value"], 4), "NA" if r["i2"] is None else fnum(r["i2"], 1)])
story += [styled_table(term_rows, [46*mm, 45*mm, 9*mm, 42*mm, 17*mm, 17*mm], cell_style="Tinyx"),
          Spacer(1, 5*mm),
          p("Excluding futility-terminated trials did not strengthen ADAS-Cog and only modestly strengthened CDR-SB. Removing all early-terminated studies reduced the number of ADCS-ADL-MCI contrasts to one. For ARIA-H, removing futility trials changed the highly heterogeneous class estimate (RR 1.65; I2=90%) to the lecanemab-donanemab pool (RR 2.14; I2=26%), illustrating how class composition can strongly affect safety heterogeneity."),
          p("Interpretation", "H2x"),
          p("The response's concern is better supported by biological activity and individual drug than by termination status alone. Early termination is also a post-randomization program characteristic and may be related to efficacy or toxicity; exclusion can introduce selection bias."),
          PageBreak()]

# Absolute safety
story += [p("5. Absolute safety effects", "H1x"),
          Image(str(FIG / "absolute_aria_e_by_antibody.png"), width=165*mm, height=101*mm),
          p("Figure 2. Agent-specific risk differences for any ARIA-E at approximately 18 months.", "Captionx")]
abs_rows = [["Outcome", "Agent", "Excess/1,000 (95% CI)", "NNH or NNTB"]]
for aid in ["4.2", "4.7", "9.1", "5.1", "6.1"]:
    for agent in ["Aducanumab", "Donanemab", "Lecanemab"]:
        r = find(DATA["absolute_safety"], analysis_id=aid, agent=agent)
        if r:
            nn = "Indeterminate" if r["number_needed"] is None else f"{r['nn_type']} {fnum(r['number_needed'],1)}"
            abs_rows.append([r["outcome"], agent,
                             f"{fnum(r['rd_per_1000'],1)} ({fnum(r['rd_ci_low_per_1000'],1)}, {fnum(r['rd_ci_high_per_1000'],1)})", nn])
story += [styled_table(abs_rows, [51*mm, 28*mm, 60*mm, 36*mm], cell_style="Tinyx"),
          p("ARIA-E excess risk was 326 per 1,000 for aducanumab (NNH 3.1), 220 per 1,000 for donanemab (NNH 4.6), and 109 per 1,000 for lecanemab (NNH 9.2). For ARIA-H, the excess was 178 per 1,000 for donanemab (NNH 5.6) and 82 per 1,000 for lecanemab (NNH 12.1). Discontinuation risk was clearly increased for donanemab and aducanumab; the lecanemab CI crossed zero."),
          p("These are trial-contrast averages, not personalized risks. APOE genotype, baseline MRI findings, anticoagulation, dose exposure, monitoring, and event definitions cannot be incorporated from the Cochrane aggregate export."),
          PageBreak()]

# Benefit harm
story += [p("6. Treatment-specific benefit and harm", "H1x"),
          Image(str(FIG / "benefit_harm_matrix.png"), width=162*mm, height=109*mm),
          p("Figure 3. ADAS-Cog raw mean difference and ARIA-E risk difference are displayed as separate dimensions. The figure deliberately imposes no utility weights.", "Captionx")]
bh_rows = [["Agent", "ADAS-Cog MD", "CDR-SB MD", "ARIA-E excess/1,000", "Discontinuation excess/1,000"]]
for r in DATA["benefit_harm"]:
    bh_rows.append([r["agent"], fnum(r["adas_md"],2), fnum(r["cdr_sb_md"],2),
                    fnum(r["aria_e_excess_per_1000"],1), fnum(r["discontinuation_excess_per_1000"],1)])
story += [styled_table(bh_rows, [31*mm, 32*mm, 30*mm, 41*mm, 42*mm]),
          p("Lecanemab and donanemab had similar reconstructed ADAS-Cog differences (-1.44 and -1.35 points), while their CDR-SB differences were -0.45 and -0.70 points. Donanemab had larger absolute ARIA-E and discontinuation differences than lecanemab in these trials. Cross-trial comparisons are not randomized head-to-head comparisons and may reflect population, monitoring, estimand, and ascertainment differences."),
          p("No single benefit-risk ranking is calculated. Such a ranking would require patient preference weights, event severity and reversibility, treatment burden, cost, and guideline-level deliberation."),
          PageBreak()]

# MID
story += [p("7. MID and MCID compatibility", "H1x"),
          p("The response correctly distinguishes statistical evidence from judgments about patient importance. To make that distinction explicit, raw-effect confidence intervals were compared with the short-horizon benchmarks quoted by Cochrane. This is a sensitivity analysis, not an endorsement of those thresholds.")]
mid_rows = [["Endpoint", "Scenario", "Benefit (95% CI), points", "Threshold", "Compatibility"]]
for r in DATA["mid_compatibility"]:
    if r["analysis_id"] in ["1.1", "2.1"]:
        scen = {"Cochrane class pool":"Class pool", "Response primary: clearing approved-generation trials":"Response primary", "Currently active agents: lecanemab + donanemab":"Lecanemab + donanemab"}.get(r["scenario"], r["scenario"])
        mid_rows.append([r["outcome"], scen,
                         f"{fnum(r['benefit_estimate'],2)} ({fnum(r['benefit_ci_low'],2)}, {fnum(r['benefit_ci_high'],2)})",
                         f"{r['threshold_points']} points", r["threshold_result"]])
story += [styled_table(mid_rows, [39*mm, 34*mm, 39*mm, 23*mm, 41*mm], cell_style="Tinyx"),
          p("At 18 months, every evaluated ADAS-Cog CI was below the 2-point MCI benchmark; the lecanemab-donanemab upper bound was 1.99 points. Every CDR-SB CI was below the 1-point MCI benchmark. These comparisons are sensitive to model choice and to the mismatch between the benchmarks' cited 6-12-month derivation and the 18-month trial horizon."),
          p("For outcomes beyond 24 months, the CIs were sometimes compatible with the lower ADAS-Cog threshold, but only two studies contributed and the threshold was not validated for that horizon. Longer follow-up therefore does not solve the threshold problem in this dataset."),
          PageBreak()]

# Target class
story += [p("8. Biological target-class analyses", "H1x")]
target_rows = [["Endpoint", "Target class", "k", "Estimate (95% CI)"]]
for r in DATA["target_class_results"]:
    if r["analysis_id"] in ["1.1", "2.1", "4.2", "9.1"]:
        target_rows.append([r["outcome"], r["target_class"], str(r["k"]),
                            f"{fnum(r['estimate'])} ({fnum(r['ci_low'])}, {fnum(r['ci_high'])})"])
story += [styled_table(target_rows, [47*mm, 50*mm, 9*mm, 69*mm], cell_style="Tinyx"),
          p("Soluble aggregate-preferring and pyroglutamate-plaque categories showed favorable cognitive estimates, while the broad aggregated/fibrillar category was closer to null. However, this category combines aducanumab, bapineuzumab, and gantenerumab, whose dose exposure and plaque removal differ substantially. Solanezumab, classified as soluble-monomer targeting, also produced small favorable estimates on some scales. Target class therefore does not replace individual-drug analysis."),
          p("The classifications summarize predominant binding preferences and are not mutually exclusive biochemical truths. Several antibodies bind more than one amyloid species, and in-vivo effects depend on affinity, exposure, effector function, and disease context."),
          PageBreak()]

# Moderator/unblinding
story += [p("9. Moderator and functional-unblinding analyses", "H1x")]
mod_rows = [["Endpoint", "Moderator", "k", "Slope (95% CI)", "P"]]
for r in DATA["moderator_results"]:
    mod_rows.append([r["outcome"], r["moderator"], str(r["k"]),
                     f"{fnum(r['slope'],4)} ({fnum(r['slope_ci_low'],4)}, {fnum(r['slope_ci_high'],4)})",
                     fnum(r["slope_p"],4)])
story += [styled_table(mod_rows, [42*mm, 58*mm, 9*mm, 49*mm, 17*mm], cell_style="Tinyx"),
          p("The ARIA-E risk-difference proxy was not associated with ADAS-Cog, MMSE, or CDR-SB effects. This does not establish successful blinding: ARIA-E is an imperfect proxy, clinical teams may remain blinded to central MRI reads, infusion reactions may unblind independently, and trial-level meta-regression cannot recover participant-level expectancy effects."),
          p("Publication year showed a nominal association with larger ADAS-Cog effects (P=0.049), but this was one of multiple exploratory moderators and is inseparable from changes in biomarker selection, antibodies, dose exposure, and trial design. Biomarker-confirmation and futility indicators were not statistically significant moderators."),
          PageBreak()]

# Influence and certainty
story += [p("10. Influence, heterogeneity, and certainty", "H1x"),
          p("Leave-one-antibody-out results demonstrate which class estimates are composition-sensitive. They should not be read as independent replications because each estimate reuses most of the same trials.")]
infl_rows = [["Endpoint", "Omitted antibody", "k", "Estimate (95% CI)", "I2"]]
for r in DATA["leave_one_agent_out"]:
    if r["analysis_id"] in ["1.1", "2.1", "4.7"]:
        infl_rows.append([r["outcome"], r["omitted_agent"], str(r["k"]),
                          f"{fnum(r['estimate'])} ({fnum(r['ci_low'])}, {fnum(r['ci_high'])})",
                          "NA" if r["i2"] is None else fnum(r["i2"],1)])
story += [styled_table(infl_rows, [45*mm, 31*mm, 9*mm, 58*mm, 19*mm], cell_style="Tinyx"),
          p("The response's criticism of moderate certainty for a highly inconsistent ARIA-H estimate is not itself a statistical hypothesis. The dataset can document the inconsistency, prediction intervals, and influence of individual agents; a revised GRADE rating additionally requires judgments about risk of bias, indirectness, imprecision, and the decision context."),
          p("For class-wide ARIA-H at 18 months, I2 was 90%. The estimate became more coherent only after the analysis effectively narrowed to lecanemab and donanemab. This supports reporting treatment-specific absolute risks and argues against a single class safety label."),
          PageBreak()]

# Limits
story += [p("11. What the Cochrane dataset cannot answer", "H1x")]
limits = [
    ["Question", "Why it remains unresolved"],
    ["Individual-level amyloid mediation", "Trial-level Centiloid associations cannot show that participants with greater clearance had greater benefit."],
    ["Continuous amyloid-positive enrollment fraction", "The export records whether confirmation was required, not a consistent participant-level fraction for every older trial."],
    ["Personalized safety", "APOE genotype, anticoagulation, baseline microhemorrhage burden, MRI surveillance, and event severity are unavailable."],
    ["Patient-valued net benefit", "No defensible universal weights exist for cognitive slowing, ARIA, infusion burden, cost, and access."],
    ["Real-world effectiveness", "Randomized trial summaries cannot substitute for ALZ-NET or comparable post-approval observational data."],
    ["Guideline recommendation", "Evidence synthesis alone does not reproduce multidisciplinary guideline methods or stakeholder deliberation."],
]
story += [styled_table(limits, [55*mm, 121*mm]),
          p("These are not merely missing statistical techniques. They require different data, explicit value judgments, or a different methodological process."),
          PageBreak()]

# Conclusions and sources
story += [p("12. Conclusions", "H1x"),
          p("The expanded analyses reinforce the need to distinguish individual anti-amyloid antibodies, their biological activity, and their absolute harms. Lecanemab and donanemab individually showed favorable estimates on central cognitive and global endpoints, but the dataset was too small to establish statistically significant treatment-by-antibody interactions. Excluding futility trials did not materially strengthen ADAS-Cog and only modestly changed CDR-SB, suggesting that biological target engagement is a more informative distinction than termination status alone."),
          p("Absolute safety estimates revealed clinically important differences: ARIA-E excess risk was approximately 109 per 1,000 for lecanemab and 220 per 1,000 for donanemab, with an even larger estimate for aducanumab. The raw efficacy confidence intervals remained below the short-horizon ADAS-Cog and CDR-SB benchmarks cited by Cochrane at 18 months, although the response is correct that threshold selection and time-horizon transfer require external validation and stakeholder judgment."),
          p("Overall, the data justify a treatment-specific, biologically informed systematic review. They do not justify a universal conclusion that all anti-amyloid antibodies are interchangeable, nor do they establish an unqualified favorable benefit-risk balance for the active agents."),
          p("Sources", "H2x")]
source_rows = [
    ["Source", "Use", "URL"],
    ["Cochrane CD016297 (2026)", "Review, row-level data, trial termination, MID discussion", "https://doi.org/10.1002/14651858.CD016297"],
    ["Snyder et al. (2026)", "Criticisms and requested alternative framing", "https://doi.org/10.1002/alz.71696"],
    ["Cummings et al. (2025)", "Predominant amyloid-species target classification", "https://pmc.ncbi.nlm.nih.gov/articles/PMC12047478/"],
    ["Muir et al. (2024)", "MID/MCID source cited by Cochrane", "https://doi.org/10.1002/alz.13770"],
    ["Lansdall et al. (2023)", "Clinically meaningful change source cited by Cochrane", "https://doi.org/10.14283/jpad.2022.102"],
    ["Imbimbo et al. (2024)", "Trial-level Centiloid mapping from prior package", "https://academic.oup.com/brain/article/147/10/3513/7754406"],
]
story += [styled_table(source_rows, [40*mm, 60*mm, 76*mm], cell_style="Tinyx"),
          Spacer(1, 5*mm),
          p("Reproducibility", "H2x"),
          p("The companion archive contains the annotated trial map, every result table, analysis code, workbook builder, report builder, and figures. Quality-control checks confirmed 17 classified studies, seven antibodies, six futility terminations, nine total early terminations, and no missing agent or termination classifications.")]

doc.build(story)
print(OUT)
